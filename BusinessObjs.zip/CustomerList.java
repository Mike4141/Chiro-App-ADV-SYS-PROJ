
package ChiroOffice;
import java.util.ArrayList;

public class CustomerList {
    
    ArrayList<CustomerBO> cList = new ArrayList<CustomerBO>();
    
    public void addPatient(CustomerBO c1) {
        cList.add(c1);
    }
    public void displayList() {
        for(int x=0;x<cList.size();x++){
            System.out.println(cList.get(x));
        }
    }
    
    
}
