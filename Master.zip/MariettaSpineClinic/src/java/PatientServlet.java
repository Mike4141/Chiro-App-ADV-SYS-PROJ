/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.PatientBO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author victo
 */
@WebServlet(urlPatterns = {"/PatientServlet"})
public class PatientServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            
        
            // ========== PROPERTIES ==========
            
            // ----- Get ID & Password from Patient Login Page -----
            String idGui = request.getParameter("uname"); // get id from GUI
            String pwGui = request.getParameter("psw"); // get password from GUI
            
            // ----- Get Patient Business Object -----
            PatientBO patient = new PatientBO(); // empty patient object
            patient.selectDB(idGui); // select patient and load lists from database

            // ----- Get ID & Password from Database -----
            String idDb = patient.getPatId(); //  get patient id from database
            String pwDb = patient.getPatPw(); // get patient password from database                  
                     
            
            
            // ========= ADD PATIENT BUSINESS OBJECT TO SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object added to Session. Scheduled.");             
            
                       
            
            // ========== CHECK ID & PASSWORD AGAINST DATABASE ==========
            if (pwGui != null && idGui != null && pwGui.equals(pwDb) && idGui.equals(idDb)) // do id and passwords match?
            {
                // go to Patient home page
                request.setAttribute("passwHintCol", "gray");
                request.setAttribute("phoneHintCol", "gray");
                RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
                rd.forward(request, response); // forward request dispatcher
                System.out.println("Webpage Loaded - patienthomepage.jsp");
            }
            else
            {
                // sends INVALID LOGIN Prompt via HTML
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Login Failed</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Invalid Login Information.</h1>");
                out.println("</body>");
                out.println("</html>");
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
