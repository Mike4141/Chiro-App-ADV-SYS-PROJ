/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.AppointmentBO;
import business.Formatter;
import business.PatientBO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author victo
 */
@WebServlet(urlPatterns = {"/PatientServlet"})
public class PatientServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
                     
        
        try{   
            
        // ++++++++++ GET TRIGGER VALUE ++++++++++
        String trigger = request.getParameter("trigger");
        if (trigger == null) trigger = "login";
        
        
        
        
        // ++++++++++ REGISTER NEW PATIENT ++++++++++
        if (trigger.equals("register"))
        {
        
        try {
            String ID, PW, FN, LN, ST, CY, SE, ZP, PH, EM, IR, PN;
            ID= request.getParameter("ID");
            PW= request.getParameter("PW");
            FN= request.getParameter("FN");
            LN= request.getParameter("LN");
            ST= request.getParameter("ST"); // addr. street
            CY= request.getParameter("CY"); // addr. city
            SE= request.getParameter("SE"); // addr. state
            ZP= request.getParameter("ZP"); // addr. zip
            PH= request.getParameter("PH");
            EM= request.getParameter("EM");
            IR= request.getParameter("IR"); // insurance
            PN= request.getParameter("PN"); // policy no.
            System.out.println("Username = "+ ID);
            System.out.println("Password = "+PW);
            System.out.println("First Name = "+ FN);
            System.out.println("Last Name = "+LN);
            System.out.println("Street = "+ ST);
            System.out.println("City = "+ CY);
            System.out.println("State = "+ SE);
            System.out.println("Zip = "+ ZP);
            System.out.println("Phone# = "+PH);
            System.out.println("Email = "+ EM);
            System.out.println("Insurer = "+IR);
            System.out.println("Policy# = "+PN);
            
            
            PatientBO p1= new PatientBO(); 
            
            p1.selectDB(ID); // first check if already exists            
            if (!p1.getPatId().equals(""))
            {
                // ========== re-direct to patient already registered page prompt ==========
                response.sendRedirect("patientregisteredexists.html");
            }
            p1 = new PatientBO(); // reset patient values
            
                        
            p1.insertDB(ID, PW, FN, LN, ST, CY, SE, ZP, PH, EM, IR, PN); // insert
            p1.selectDB(ID); // check to see if insert worked
            
            if (!p1.getPatId().equals(""))
            {
                // ========== re-direct to confirmation page ==========
                response.sendRedirect("patientregistered.html");
            }  
            else
            {
                // ========== re-direct to generalized error page ==========
                response.sendRedirect("error.html");     
            }
            
            }
            catch (Exception e) {
            // ========== Go to generalized error page ==========
            response.sendRedirect("error.html");
            }       
        }
            
            
            
        
        // ++++++++++ UPDATE PERSONAL INFORMATION ++++++++++        
        if (trigger.equals("updateinfo"))                
        {
            // ========== GET PATIENT BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            PatientBO patient = (PatientBO)session.getAttribute("patient"); // get patient object from session 
            System.out.println("Patient Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========
            String pwGui, fnameGui, lnameGui, phoneGui, emailGui, streetGui,  
                          cityGui, stateGui, zipGui, insureGui, policyGui;
            pwGui = request.getParameter("showpw"); // get password from GUI
            fnameGui = request.getParameter("showfname"); // get phone from GUI
            lnameGui = request.getParameter("showlname"); // get email from GUI
            phoneGui = request.getParameter("showphone"); // get phone from GUI
            emailGui = request.getParameter("showemail"); // get email from GUI
            streetGui = request.getParameter("showstreet"); // get street from GUI
            cityGui = request.getParameter("showcity"); // get city from GUI
            stateGui = request.getParameter("showstate"); // get state from GUI
            zipGui = request.getParameter("showzip"); // get zip from GUI
            insureGui = request.getParameter("showinsure"); // get insurance from GUI
            policyGui = request.getParameter("showpolicy"); // get policy number from GUI
            
            
            
            // ========== UPDATE PERSONAL INFORMATION IN DATABASE ==========  
            patient.setPatPw(pwGui);
            patient.setPatFn(fnameGui);
            patient.setPatLn(lnameGui);
            patient.setPatPhone(phoneGui);
            patient.setPatEmail(emailGui);
            patient.setPatStreet(streetGui);
            patient.setPatCity(cityGui);
            patient.setPatState(stateGui);
            patient.setPatZip(zipGui);
            patient.setPatInsurer(insureGui);
            patient.setPatPolicyNo(policyGui);
            patient.updateDB();


            
            // ========== UPDATE PATIENT AND LISTS ==========
            patient.selectDB(patient.getPatId());
            
            
            // ========== CHECK IF UPDATE TOOK EFFECT ==========
            if (patient.getPatPw().equals(pwGui)
            && !patient.getPatFn().equals(fnameGui)
            && !patient.getPatLn().equals(lnameGui)
            && !patient.getPatPhone().equals(phoneGui)
            && !patient.getPatEmail().equals(emailGui)
            && !patient.getPatStreet().equals(streetGui)
            && !patient.getPatCity().equals(cityGui)
            && !patient.getPatState().equals(stateGui)
            && !patient.getPatZip().equals(zipGui)
            && !patient.getPatInsurer().equals(insureGui)
            && !patient.getPatPolicyNo().equals(policyGui))
            {
                // ========== re-direct to specific action error page ==========
                response.sendRedirect("patient0infoupdate.html");
            }
            
            
            // ========= RE-ADD UPDATED PATIENT BUSINESS OBJECT ==========
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object re-added to Session. Scheduled.");             
            
            
            // ========== RE-LOAD PATIENT HOME PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");
        }
        
        
        
        
        // ++++++++++ SCHEDULE APPOINTMENT ++++++++++
        if (trigger.equals("schedule"))                
        {
            // ========== GET PATIENT BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            PatientBO patient = (PatientBO)session.getAttribute("patient"); // get patient object from session 
            System.out.println("Patient Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========            
            String newApptDay, newApptTimeIn, newApptTimeOut, newApptDocId;
            newApptDay = request.getParameter("readyday"); // get new appointment day from hidden input
            newApptTimeIn = request.getParameter("readytimein"); // get new appointment time in from hidden input
            newApptTimeOut = request.getParameter("readytimeout"); // get new appointment time out from hidden input
            newApptDocId = request.getParameter("readydocid"); // get new appointment doctor id from hidden input
            AppointmentBO newAppt = new AppointmentBO(); // new appointment object for scheduling
            AppointmentBO justAppt = new AppointmentBO(); // new appointment object for indicating just added appt. in GUI
            Formatter format = new Formatter();
                        
            // CHECK IF ENTRY ALREADY EXISTS *IT SHOULD NOT*
            newAppt.selectDB(newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn);
            if (!newAppt.getPatId().equals("") 
            && !newAppt.getDocId().equals("") 
            && !newAppt.getDay().equals("")
            && !newAppt.getTimeIn().equals(""))
            {
                // ========== re-direct to specific action failed page ==========
                response.sendRedirect("patient1apptalready.html");
            }
            newAppt = new AppointmentBO(); // reset for insert 
            
            // ========== ADD NEW APPOINTMENT FOR PATIENT ==========           
            newAppt.insertDB(patient.getPatId(), newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn, newApptTimeOut);
            newAppt = new AppointmentBO(); // reset for last check 
            
            // CHECK IF ENTRY EXISTS AFTER INSERT *IT SHOULD*
            newAppt.selectDB(newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn);
            if (newAppt.getPatId().equals("") 
            && newAppt.getDocId().equals("") 
            && newAppt.getDay().equals("")
            && newAppt.getTimeIn().equals(""))
            {
                // ========== re-direct to generic action failed page ==========
                response.sendRedirect("actionfailed.html");
            }
            
            
            
            // ========== ADD LATEST SCHEDULED APPT. TO PATIENT ==========
            justAppt.setDocId(newApptDocId);
            justAppt.setDay(newApptDay);
            justAppt.setTimeIn(newApptTimeIn);
            patient.setLatestAppt(justAppt);
            
            
            // ========== UPDATE PATIENT AND LISTS ==========
            patient.selectDB(patient.getPatId()); 
            
            
            // ========= RE-ADD UPDATED PATIENT BUSINESS OBJECT ==========
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object re-added to Session. Scheduled.");    
            

            // ========== RE-LOAD PATIENT HOME PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");
        }
                
        
        
        
        // ++++++++++ CANCEL APPOINTMENT ++++++++++
        if (trigger.equals("cancel"))                
        {
            // ========== GET PATIENT BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            PatientBO patient = (PatientBO)session.getAttribute("patient"); // get patient object from session 
            System.out.println("Patient Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========            
            String newApptDay, newApptTimeIn, newApptDocId;
            newApptDay = request.getParameter("readyday"); // get new appointment day from hidden input
            newApptTimeIn = request.getParameter("readytimein"); // get new appointment time in from hidden input
            newApptDocId = request.getParameter("readydocid"); // get new appointment doctor id from hidden input
            AppointmentBO endAppt = new AppointmentBO(); // new appointment object for scheduling
            Formatter format = new Formatter();
                        
            
            // CHECK IF ENTRY ALREADY EXISTS *IT SHOULD*
            endAppt.selectDB(newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn);
            if (endAppt.getPatId().equals("") 
            && endAppt.getDocId().equals("") 
            && endAppt.getDay().equals("")
            && endAppt.getTimeIn().equals(""))
            {
                // ========== re-direct to specific action failed page ==========
                response.sendRedirect("patient0apptexists.html");
            }
            endAppt = new AppointmentBO(); // re-set appointment for delete
            
            
            // ========== DELETE APPOINTMENT FOR PATIENT ==========   
            endAppt.setPatId(patient.getPatId());
            endAppt.setDocId(newApptDocId);
            endAppt.setDay(format.formatDateSubmit(newApptDay));
            endAppt.setTimeIn(newApptTimeIn);
            endAppt.deleteDB();    
            endAppt = new AppointmentBO(); // re-set appointment for last check
                        
            
            // ========== CHECK IF ENTRY STILL EXISTS *IT SHOULD NOT* =========            
            endAppt.selectDB(newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn);
            if (!endAppt.getPatId().equals("") 
            && !endAppt.getDocId().equals("") 
            && !endAppt.getDay().equals("")
            && !endAppt.getTimeIn().equals(""))
            {
                // ========== Go to generic action failed page ==========
                response.sendRedirect("actionfailed.html");
            }
            
            
            
            // ========== UPDATE PATIENT AND LISTS ==========
            patient.selectDB(patient.getPatId());           
            
            
            // ========= RE-ADD UPDATED PATIENT BUSINESS OBJECT ==========
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object re-added to Session. Scheduled.");                         
            

            // ========== RE-LOAD PATIENT HOME PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");
        }        
        
        
        
        
        // ++++++++++ LOGIN ++++++++++
        if (trigger.equals("login"))                
        {
            // ========== PROPERTIES ==========
            
            // ----- Get ID & Password from Patient Login Page -----
            String idGui = request.getParameter("uname"); // get id from GUI
            String pwGui = request.getParameter("psw"); // get password from GUI
            
            // ----- Get Patient Business Object -----
            PatientBO patient = new PatientBO(); // empty patient object
            patient.selectDB(idGui); // select patient and load lists from database

            // ----- Get ID & Password from Database -----
            String idDb = patient.getPatId(); //  get patient id from database
            String pwDb = patient.getPatPw(); // get patient password from database                  
                     
            
            
            // ========= ADD PATIENT BUSINESS OBJECT TO SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object added to Session. Scheduled.");             
            
                       
            
            // ========== CHECK ID & PASSWORD AGAINST DATABASE ==========
            if (pwGui != null && idGui != null && pwGui.equals(pwDb) && idGui.equals(idDb)) // do id and passwords match?
            {
                // go to Patient Logged In Page
                RequestDispatcher rd = request.getRequestDispatcher("patientloggedin.html"); // create request dispatcher
                rd.forward(request, response);
                System.out.println("Webpage Loaded - patientloggedin.html");
            }
            else
            {
                // go to Patient Login Failed Page
                RequestDispatcher rd = request.getRequestDispatcher("patientloginfailed.html");
                rd.include(request, response);
            }      
        }
        
        
        
        // ++++++++++ LOGOUT ++++++++++
        if (trigger.equals("logout"))                
        {
            HttpSession session = request.getSession();
            if(session.getAttribute("patient") != null)
            {
            session.removeAttribute("patient");
            session.invalidate();
            response.sendRedirect("patientlogin.html");                 
            }
            else
            response.sendRedirect("patientlogin.html");
        }
        
        
        
    }
    catch(NullPointerException e)
    {
        /* IF NULL POINTER EXCEPTION OCCURS IN SERVLET - YOU ARE LIKELY NOT
        LOGGED IN AT THE MOMENT - SO YOU WILL BE RE-DIRECTED ACCORDINGLY */
           
        // go to Patient Home Page (session or "trigger" variable related) 
        // ----- this homepage will simply show that user is not logged in
        RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp");
        rd.include(request, response);
    }
    catch(Exception e)
    {           
        // go to Unkown Error Home Page 
        RequestDispatcher rd = request.getRequestDispatcher("error.html");
        rd.include(request, response);
    }              
   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
