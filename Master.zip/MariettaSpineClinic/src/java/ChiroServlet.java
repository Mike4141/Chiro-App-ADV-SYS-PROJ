/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.ChiroBO;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/ChiroServlet"})
public class ChiroServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
                        
            
            
            // =================== Get ID & Password from Doctor Login Page
            String idGui, pwGui;
            idGui = request.getParameter("uname"); // get id from GUI
            pwGui = request.getParameter("psw"); // get password from GUI
            System.out.println("ID from Webpage = " + idGui);
            System.out.println("Password from Webpage = " + pwGui);
                        
            // =================== Get ID & Password against Database
            /*
            (IMPORTANT make sure import Business.ChiroBO 
            interface for object reference to use ChiroBO object
            in the Servlet)
            */            
            ChiroBO c1 = new ChiroBO(); // empty chiropractor object
            c1.selectDB(idGui); // look up chiropractor id in Database
            c1.logApptListDB(); // look up chiropractor accounts
            String idDb = c1.getChiroId(); // retrieve Database id
            String pwDb = c1.getChiroPw(); // retrieve Database Password
            System.out.println("ID from Database = " + idDb);
            System.out.println("Password from Database = " + pwDb);
            
            
            // =================== Add Chiropractor Business Object to Session
            HttpSession session; // declare session
            session = request.getSession(); // get session
            session.setAttribute("nowChiro", c1); // add chiropractor object to session
            System.out.println("Chiropractor Object added to Session. Scheduled.");
           
            
            // =================== Check ID & Password against Database
            if (pwGui.equals(pwDb) && idGui.equals(idDb)) // do id and passwords match?
            {
                    // go to Doctor home page
                    request.setAttribute("docfn", c1.getChiroFn());
                    request.setAttribute("docln", c1.getChiroLn());
                    request.setAttribute("docid", c1.getChiroId());
                    request.setAttribute("docpw", c1.getChiroPw());
                    request.setAttribute("docphone", c1.getChiroPhone());
                    request.setAttribute("docemail", c1.getChiroEmail());
                    request.setAttribute("docappts", c1.getApptList());
                    request.setAttribute("docpats", c1.getPatList());
                    request.setAttribute("docdays", c1.getDayList());
                    request.setAttribute("datecb", "ALL DATES");
                    RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
                    rd.forward(request, response); // forward request dispatcher
                    System.out.println("Webpage Loaded - doctorhomepage.jsp");
            }
            else
            {
                // sends INVALID LOGIN Prompt via HTML
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Login Failed</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Invalid Login Information.</h1>");
                out.println("</body>");
                out.println("</html>");
            }
   
                    
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
