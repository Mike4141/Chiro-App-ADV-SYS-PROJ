/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.AppointmentBO;
import business.ChiroBO;
import business.FormatChecker;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/ChiroUpdateServlet"})
public class ChiroUpdateServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();                        
            
        
        
        
            // =================== Add Chiropractor Business Object to Session
            HttpSession session; // declare session
            session = request.getSession(); // get session
            ChiroBO c1 = (ChiroBO)session.getAttribute("nowChiro"); // get chiropractor object from session 
            System.out.println("Chiropractor Object added to Session. Scheduled.");
            //
            FormatChecker fc = new FormatChecker(); // empty format checker object
                
            
            // =================== Get ID & Password from Doctor Home Page
            String pwGui, phoneGui, emailGui;
            pwGui = request.getParameter("showpw"); // get password from GUI
            phoneGui = request.getParameter("showphone"); // get phone from GUI
            emailGui = request.getParameter("showemail"); // get email from GUI
            String pwIndColor = "gray"; // color of the password hint based on input 
            String phoneIndColor = "gray"; // color of the phone hint based on input 
            String initEditInfo = ""; // Edit mode on start up? default is "" = 'no'
            System.out.println("Password from Webpage = " + pwGui);
            System.out.println("Phone Number from Webpage = " + phoneGui);
            System.out.println("Email from Webpage = " + emailGui);
            
            
            
            // ========== GUI FORMATTING
            List<String> patList = new ArrayList<>(); // patient list for HTML
            List<String> patInfo = new ArrayList<>(); // patient info for HTML
            List<String> dayList = new ArrayList<>(); // day/date list for HTML
            List<AppointmentBO> apptList = new ArrayList<>(); // appointment list for HTML
            
            // re-format patient list and info (without directly changing nowChiro) for HTML            
            if (c1.getPatList() != null) 
            {
                
                for(String pat:c1.getPatList())
                {
                    patList.add(fc.formatPatientEntryHtmlDB(pat));    
                    patInfo.add(fc.formatPatientInfoHtmlDB(pat));                
                }                
            }
            
            // re-format dates/days of the date list (wihtout directly changing nowChiro) for HTML
            if (c1.getDayList() != null) 
            {
                for(String day:c1.getDayList())
                {
                dayList.add(fc.formatDayHtml(day));
                }
            }
            
            // re-format appointment list (without directly changing nowChiro) for HTML
            if (c1.getApptList() != null) 
            {
                for(AppointmentBO appt:c1.getApptList())
                {
                    
                AppointmentBO apptEntry = new AppointmentBO(
                          fc.formatPatientEntryHtmlDB(appt.getCustID()), 
                          c1.getChiroId(), 
                          fc.formatDayHtml(appt.getDay()), 
                          fc.formatTimeHtml(appt.getTimeIn()), 
                          fc.formatTimeHtml(appt.getTimeOut()));

                // adds appointment entry to appointment list
                apptList.add(apptEntry);
                }
            }
            
               
            
            // ========== UPDATE PERSONAL INFORMATION IN DATABASE  
            if (fc.checkCustPw(pwGui) == true && fc.checkPhone(phoneGui) == true)
            {
                c1.setChiroPw(pwGui);
                c1.setChiroPhone(phoneGui);
                c1.setChiroEmail(emailGui);
                c1.updateDB();
            }   
            // ----------  up-to-date phone HTML view
            String phoneShow = fc.formatPhoneHtml(c1.getChiroPhone());
            //
            if (fc.checkCustPw(pwGui) == false || fc.checkPhone(phoneGui) == false)
            {
                initEditInfo = "editInfo()"; // re-start page in edit mode due to incorrect user info
            }
            // ---------- red indicators for incorrect update input format
            if (fc.checkCustPw(pwGui) == false)
            pwIndColor = "red";
            if (fc.checkPhone(phoneGui) == false)
            phoneIndColor = "red";
            
                       
            
            // =================== Check ID & Password against Database

            // go to Doctor home page
            request.setAttribute("docfn", c1.getChiroFn());
            request.setAttribute("docln", c1.getChiroLn());
            request.setAttribute("docid", c1.getChiroId());
            request.setAttribute("docpw", c1.getChiroPw());                   
            request.setAttribute("docemail", c1.getChiroEmail());
            request.setAttribute("docphoneRAW", c1.getChiroPhone());
            request.setAttribute("docphone", phoneShow);                    
            request.setAttribute("docappts", apptList);
            request.setAttribute("docpats", patList);
            request.setAttribute("docpatsinfo", patInfo);
            request.setAttribute("docdays", dayList); 
            request.setAttribute("pwHintCol", pwIndColor);
            request.setAttribute("phoneHintCol", phoneIndColor);
            request.setAttribute("initEditInfo", initEditInfo);
            RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - doctorhomepage.jsp");
      
   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
