/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.ChiroBO;
import business.FormatChecker;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/ChiroUpdateServlet"})
public class ChiroUpdateServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();                        
            
            
            // =================== Get New User Info from Textboxes in Doctor Home Page
            String idGui, pwGui, fnGui, lnGui, phoneGui, emailGui, dateCbox;
            idGui = request.getParameter("showid"); // get id from GUI
            pwGui = request.getParameter("showpw"); // get password from GUI
            phoneGui = request.getParameter("showphone"); // get id from GUI
            emailGui = request.getParameter("showemail"); // get password from GUI
            dateCbox = request.getParameter("datelister"); // get selected appointment date from GUI ComboBox           
            
            // =================== Validate User Info entered in Doctor Home Page
            boolean updateValid = true; // starts out true until proven false
            
            
            FormatChecker fc = new FormatChecker(); 
            //
            if (fc.checkPhone(phoneGui) == false)
            {
                updateValid = false;
                request.setAttribute("showphone", "incorrect format");
            }
            
            
            // =================== Update User Info for Doctor in Database
            
            // Grab ChiroBO object from session
            HttpSession session; // declare session
            session = request.getSession(); // get session
            ChiroBO c1 = (ChiroBO)session.getAttribute("nowChiro"); // get chiropractor object from session         
            
            //set ChiroBO properties
            /* --- check for null values from disabled fields - only 
               null values can be returned from disabled fields - but
               real values can be wriiten to them. these particular
               fields are necessary for new update information, so
               this check also saves an unnecessary DB update by
               simple retransfering current session Chiropractor
               business object--- */
            if (idGui != null || pwGui != null || phoneGui != null || emailGui != null)
            {
            c1.setChiroId(idGui);
            c1.setChiroPw(pwGui);
            c1.setChiroFn(c1.getChiroFn());
            c1.setChiroLn(c1.getChiroLn());
            c1.setChiroPhone(phoneGui);
            c1.setChiroEmail(emailGui);
            
            // format correct?
            if (updateValid == true)
            c1.updateDB();             
            
            }
            
           
            
            // Re-Load Doctor home page
            request.setAttribute("docfn", c1.getChiroFn());
            request.setAttribute("docln", c1.getChiroLn());
            request.setAttribute("docid", c1.getChiroId());
            request.setAttribute("docpw", c1.getChiroPw());
            request.setAttribute("docphone", c1.getChiroPhone());
            request.setAttribute("docemail", c1.getChiroEmail());
            
            
            request.setAttribute("docappts", c1.getApptList());
            request.setAttribute("docpats", c1.getPatList());
            request.setAttribute("docdays", c1.getDayList());
            request.setAttribute("datecb", dateCbox);
            RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Re-Loaded - doctorhomepage.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
