/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.sql.*;

/**
 *
 * @author victo
 */

public class FormatChecker {
    
    
    // ---------- check phone format
    public boolean checkPhone(String phone)
    { 
        boolean correct = true;
        int testPhone1 = 0;
        int testPhone2 = 0;
        
        try
        { 
            testPhone1 = Integer.parseInt(phone.substring(0, 6)); 
            testPhone2 = Integer.parseInt(phone.substring(7, 10));
            if (phone.length() != 10)
            correct = false;
        } 
        catch(Exception e)
        {   
            System.out.print("PARSE EXCEPTION = " + e);
            correct = false; 
        }
        finally
        {
        return correct;
        }
    }
    
    
    
    // ---------- check customer/patient password format
    public boolean checkCustPw(String password)
    { 
        boolean correct = false;
        int passCount = password.length();
        
        // check the character length of password
        if (passCount == 4)
        correct = true;
        
        return correct;
    }
    
    
    
    // ---------- format day / date for HTML
    public String formatDayHtml(String day)
    { 
        // extract date
        String dateFormatted = day.substring(0, 10);
        
        return dateFormatted;
    }
    
    
    
    // ---------- format time for HTML
    public String formatTimeHtml(String time)
    { 
        
    String timeFormatted = "";    
    try{
        // parse initial value
        double whole = Math.floor(Double.valueOf(time));
        double remainder = Double.valueOf(time) - Math.floor(Double.valueOf(time));
        String frontZero = "";
        String backZero = "";
        String abbr = "";       
        String hr = "";
        String min = "";
        
        // assign abbreviation
        if (whole >= 12)
        abbr = "PM"; 
        else
        abbr = "AM"; 
        
        // convert to hours
        if (whole >= 13)
        {
            whole-=12; 
            hr = (int)whole + "";
        }
        else
        hr = (int)whole + "";        
        
        // convert to minutes
        min = (int)(Math.round(60 * remainder)) + "";   
        
        // ensure 4-digit time output
        if (whole <= 9)
        frontZero = "0";
        if (remainder <= .15)
        backZero = "0";

        // concatenate strings for return
        timeFormatted = frontZero + hr + ":" + min + backZero + " " + abbr;
        }
        catch(Exception e)
        {
           timeFormatted = "invalid time entered";
        }
        
        return timeFormatted;
    }
    
    
    // ---------- format phone number for HTML (used in Servlets)
    public String formatPhoneHtml(String phone)
    { 
        // apply pattern / format
        /* 
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
        would be better normally - but <input elements in HTML require &nbsp; for spaces.
        */
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1)&nbsp;$2-$3");
        
        return phoneFormatted;
    }
    
    
        // ---------- format phone number for HTML (used in Servlets)
    public String formatPhone(String phone)
    { 
        // apply pattern / format
        /* 
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1)&nbsp;$2-$3");
        would be better for certain fields/types that require $nbsp; for spacing
        */
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
        
        return phoneFormatted;
    }
    
    
    // ========== DATABASE METHODS
    // ---------- format customer id by adding associated name for HTML (used in Servlets)
    public String formatPatientEntryHtmlDB(String custid)
    { 
        String idPlusName = ""; // new HTML presentation string
    try {           
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT CustID, CustLN, CustFN FROM Customers WHERE CustID = '" + custid + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            idPlusName = rs.getString(1) + " "  // concantenate customer id to new string
                       + rs.getString(2) + ", " // concantenate customer last name to new string
                       + rs.getString(3);       // concantenate customer first name to new string 

            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    

        return idPlusName;
    }
    
        
    
    // ---------- format chiropractor id by adding associated name for HTML (used in Servlets)
    public String formatChiroEntryHtmlDB(String chiroid)
    { 
        String idPlusName = ""; // new HTML presentation string
    try {           
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT ChiroID, ChiroLN, ChiroFN FROM Chiropractors WHERE ChiroID = '" + chiroid + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            idPlusName = rs.getString(1) + " "  // concantenate chiropractor id to new string
                       + rs.getString(2) + ", " // concantenate chiropractor last name to new string
                       + rs.getString(3);       // concantenate chiropractor first name to new string 

            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    

        return idPlusName;
    }
    
    
    
     // ---------- create an info packet from customer/patient id for HTML (used in Servlets)
    public String formatPatientInfoHtmlDB(String custid)
    { 
        String idPlusInfo = ""; // new HTML presentation string
    try {           
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT CustID, CustFN, CustLN, CustPhone, CustEmail, CustAddr FROM Customers WHERE CustID = '" + custid + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            idPlusInfo = "ID      : " + rs.getString(1) + "\n" // concantenate customer id to new string
                       + "Name    : " + rs.getString(2) // concantenate customer firt name to new string
                       + " " + rs.getString(3) + "\n" // concantenate customer last name to new string 
                       + "Phone   : " + formatPhoneHtml(rs.getString(4)) + "\n" // concantenate customer phone number to new string 
                       + "Email   : " + rs.getString(5) + "\n" // concantenate customer email to new string 
                       + "Address : " + rs.getString(6) + "\n"; // concantenate customer address to new string 

            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
            
            
            // ---------- NEW SQL SELECTION. add to the patient description
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            sql = "SELECT ChiroID, Day, TimeIn, TimeOut FROM AppointmentHistory WHERE CustID = '" + custid + "' ORDER BY Day DESC";
            System.out.println(sql);
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            int counter = 0; // ensures only 3 entries
            idPlusInfo += "\nMOST RECENT APPOINTMENTS...\n"
                        + "DATE       |TIME                |DOCTOR\n";
            while (counter < 3 && rs.next()) // check cursor position
            {
            idPlusInfo += formatDayHtml(rs.getString(2)) + " |"  // concantenate day/date to return string
                        + formatTimeHtml(rs.getString(3)) + " - "   // concantenate time in to return string 
                        + formatTimeHtml(rs.getString(4)) + " |"    // concantenate time out to return string 
                        + formatChiroEntryHtmlDB(rs.getString(1)) + "\n";   // concantenate chiropractor id to return string 
            counter++;
            }
            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    

        return idPlusInfo;
    }
    
    
    
    
    // ========== MAIN METHOD 
    public static void main(String[] args)
    {
       FormatChecker fc = new FormatChecker();
       System.out.println(fc.formatPatientEntryHtmlDB("3001"));
       System.out.println(fc.formatPatientInfoHtmlDB("3001"));
    }
    
}
