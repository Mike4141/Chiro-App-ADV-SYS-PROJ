/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author victo
 */
public class FormatChecker {
    
    public boolean checkPhone(String phone)
    { 
        boolean correct = true;
        int testPhone1 = 0;
        int testPhone2 = 0;
        
        try
        { 
            testPhone1 = Integer.parseInt(phone.substring(0, 6)); 
            testPhone2 = Integer.parseInt(phone.substring(7, 10));
            if (phone.length() != 10)
            correct = false;
        } 
        catch(Exception e)
        {   
            System.out.print("PARSE EXCEPTION = " + e);
            correct = false; 
        }
        
        return correct;
    }
    
    // ========== MAIN METHOD 
    public static void main(String[] args)
    {
       // test code
    }
    
}
