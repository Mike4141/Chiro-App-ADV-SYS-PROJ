package business;

import java.sql.*;
import java.util.*;

public class ClientBO 
{    
    // =================== PROPERTIES ===================
    private String custId, custPw, custFn, custLn, custAddr, custPhone, custEmail;
    
    
    // =================== CONSTRUCTORS ===================    
    // Empty
    public ClientBO()
    {
        custId = "";
        custPw = ""; 
        custFn = ""; 
        custLn = ""; 
        custAddr = ""; 
        custPhone = ""; 
        custEmail = "";
    }    
    // Assign
    public ClientBO(String id, String password, String fname, String lname, 
                    String address, String phone, String email)
    {
        custId = id;
        custPw = password; 
        custFn = fname; 
        custLn = lname; 
        custAddr = address; 
        custPhone = phone; 
        custEmail = email;
    }
    
    
    // =================== GET / SET METHODS ===================     
    public String getCustId(){ return custId; } // get customer id
    public void setCustId(String value){ custId = value; } // set customer id
    public String getCustPw(){ return custPw; } // get customer password
    public void setCustPw(String value){ custPw = value; } // set customer password
    public String getCustFn(){ return custFn; } // get customer first name
    public void setCustFn(String value){ custFn = value; } // set first name
    public String getCustLn(){ return custLn; } // get customer last name
    public void setCustLn(String value){ custLn = value; } // set last name
    public String getCustAddr(){ return custAddr; } // get customer address
    public void setCustAddr(String value){ custAddr = value; } // set customer address
    public String getCustPhone(){ return custPhone; } // get customer phone
    public void setCustPhone(String value){ custPhone = value; } // set customer phone
    public String getCustEmail(){ return custEmail; } // get customer email
    public void setCustEmail(String value){ custEmail = value; } // set customer email
    
    
    
    // =================== DATABASE METHODS =================== 

    // -------------------- select method --------------------
    public void selectDB(String id) 
    {
    try {
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT * FROM Customers WHERE CustID = '" + id + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            setCustId(rs.getString(1)); // set customer id 
            setCustPw(rs.getString(2)); // set customer password
            setCustFn(rs.getString(3)); // set customer first name
            setCustLn(rs.getString(4)); // set customer last name
            setCustAddr(rs.getString(5)); // set customer address
            setCustPhone(rs.getString(6)); // set customer phone
            setCustEmail(rs.getString(7)); // set customer email
            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    
    } // end of select method
            
    
    // ==================== Main Method ====================
    public static void main(String[] args)
    {        

    } // End of Main Method


} // End of class