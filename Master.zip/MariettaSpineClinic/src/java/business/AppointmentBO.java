package business;

import java.sql.*;

public class AppointmentBO {
    
    
    // ========== PROPERTIES ==========
    private String patId, docId, day, timeIn, timeOut;
        
    
    
    
    // ========== CONSTRUCTORS ==========
    
    // ----- Clear -----
    public AppointmentBO() 
    {
        patId = ""; 
        docId = "";
        day = "";
        timeIn = "";
        timeOut = "";
    }
    
    // ----- Assign -----
    public AppointmentBO(String _accountNo, String _docId, String _day, String _timeIn, String _timeOut) 
    {
        patId = _accountNo;
        docId = _docId;
        day = _day;
        timeIn = _timeIn;
        timeOut = _timeOut;
    }
    
    

    
    // ========== GET / SET METHODS ==========
    
    // ----- Get / Set. Account Number ----- 
    public String getPatId(){ return patId; }
    public void setPatId(String value) { this.patId = value; }

    // ----- Get / Set. Doctor ID ----- 
    public String getDocId() { return docId; }
    public void setDocId(String value) { this.docId = value; }

    // ----- Get / Set. Day -----
    public String getDay() { return day; }
    public void setDay(String value) { this.day = value; }

    // ----- Get / Set. Time In -----
    public String getTimeIn() { return timeIn; }
    public void setTimeIn(String value) { this.timeIn = value; }
    
    // ----- Get / Set. Time Out -----
    public String getTimeOut() { return timeOut; }
    public void setTimeOut(String value) { this.timeOut = value; }
    
    

    
    // ========== DATABASE METHODS ==========
    
    // ----- Select. Appointment Entry with Account Number ----- 
    public void selectDB(String _doctorId, String _day, String _timeIn) 
    {
    try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("first step db connection");
            Statement stmt = con.createStatement();
            ResultSet rs;
            System.out.println("DB Connected");
            /* exolicitly outlining the select order 
            ensures that the information is taken in 
            the correct order despite a lack of key */
            String sql = "SELECT PatID, DocID, Day, TimeIn, TimeOut FROM Appointments WHERE "
                    + "DocID = '" + _doctorId + "' AND Day = '" + _day + "' AND TimeIn = '" + _timeIn + "'";
            System.out.println(sql);
            rs = stmt.executeQuery(sql);
            rs.next();
            setPatId(rs.getString(1));
            setDocId(rs.getString(2));
            setDay(rs.getString(3));
            setTimeIn(rs.getString(4));
            setTimeOut(rs.getString(5));
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }

    // ----- Insert. Account Entry with Properties -----
    public void insertDB(String _patId, String _doctorId, String _day, String _timeIn , String _timeOut ) {
        patId = _patId;
        docId = _doctorId;
        day = _day;
        timeIn = _timeIn;
        timeOut = _timeOut;
        
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("first step db connection");
            Statement stmt = con.createStatement();
            ResultSet rs;
            System.out.println("DB Connected");
            String sql = "Insert into Appointments(PatID, DocID, Day, TimeIn, TimeOut) values('"+getPatId()+"',"+ 
                                                      "'"+getDocId()+"',"+ 
                                                      "'"+getDay()+"',"+
                                                      "'"+getTimeIn()+"',"+
                                                      "'"+getTimeOut()+"')";
            System.out.println(sql);
            stmt.execute(sql);
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }

    
    // ----- Delete. Account Entry with Account Number -----
    public void deleteDB() 
    {
    try {        
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("Delete Connected");
            Statement stmt = con.createStatement();
            String sql = "DELETE FROM Appointments WHERE DocID='"+getDocId()+"' AND Day='"+getDay()+"' AND TimeIn='"+getTimeIn()+"'";
            System.out.println(sql);
            stmt.execute(sql);
            con.close();
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }    
    

    
    
    
    
    // ========== PRINT METHOD ==========
    public void print() 
    {
        System.out.println("Patient ID :     "+ getPatId());
        System.out.println("Doctor ID  :     "+ getDocId());
        System.out.println("Date       :     "+ getDay());
        System.out.println("Time In    :     "+ getTimeIn());
        System.out.println("Time Out   :     "+ getTimeOut());
        System.out.println("=========================");
    }
    
        
    
    
    // ========== MAIN METHOD ==========
    public static void main(String[] args) 
    {         
        AppointmentBO a1 = new AppointmentBO();  
        a1.selectDB("2000", "2022-10-17 00:00:00", "15");
        /*
        a1.insertDB("3001", "2003", "2022-07-09 00:00:00", "7", "7.5");
        a1.setPatId("3001");
        a1.setDocId("2003");
        a1.setDay("2022-07-09 00:00:00");
        a1.setTimeIn("7");
        a1.deleteDB();
        */
    }
    
}