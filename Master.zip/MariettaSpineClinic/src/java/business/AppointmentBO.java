
package business;
import java.sql.*;

public class AppointmentBO {
    
    private String custID, chiroID, day, timeIn, timeOut;
    
    public AppointmentBO() {
        custID = ""; 
        chiroID = "";
        day = "";
        timeIn = "";
        timeOut = "";
    }
    
    public AppointmentBO(String CustomerId, String ChiroID, String Day, String TimeIn, String TimeOut) {
        custID = CustomerId;
        chiroID = ChiroID;
        day = Day;
        timeIn = TimeIn;
        timeOut = TimeOut;
    }

    public String getCustID() {
        return custID;
    }

    public void setCustID(String custID) {
        this.custID = custID;
    }

    public String getChiroID() {
        return chiroID;
    }

    public void setChiroID(String chiroID) {
        this.chiroID = chiroID;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }
    
    
    public void display() {
        System.out.println("Customer ID :                       "+ getCustID());
        System.out.println("Chiropractor ID :                   "+ getChiroID());
        System.out.println("Date :                              "+ getDay());
        System.out.println("Time In :                           "+ getTimeIn());
        System.out.println("Time Out :                          "+ getTimeOut());
        System.out.println("========================================================");
    }
    
    
    public static void main(String[] args) { 
        /*
        AppointmentBO a1 = new AppointmentBO();
        a1.selectDB("3001");
        a1.display();  
        
        AppointmentBO a2 = new AppointmentBO();
        a2.insertDB("3300", "2001", "1/14/2022", "2:00", "3:00");
        a2.display();
        
        AppointmentBO a3 = new AppointmentBO();
        a3.selectDB("3300");
        a3.updateDB();
        
        AppointmentList list = new AppointmentList();
        AppointmentBO a1 = new AppointmentBO("3003", "2001", "4/4/2022", "1:00", "2:00");
        AppointmentBO a2 = new AppointmentBO("3003", "2001", "4/8/2022", "1:00", "2:00");
        AppointmentBO a3 = new AppointmentBO("3003", "2001", "4/12/2022", "1:00", "2:00");
        AppointmentBO a4 = new AppointmentBO("3003", "2001", "4/21/2022", "1:00", "2:00");
        list.addPatient(a1);
        list.addPatient(a2);
        list.addPatient(a3);
        list.addPatient(a4);
        list.displayList();
       
        
        AppointmentBO a1 = new AppointmentBO();
        a1.selectDB("3001");
        a1.getAppointments("3001");
        a1.display();
        
         */
    }
    
}
