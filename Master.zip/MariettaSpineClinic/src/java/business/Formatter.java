/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.sql.*;

/**
 *
 * @author victo
 */

public class Formatter {
    
    
    // ---------- check phone format
    public boolean checkPhone(String phone)
    { 
        boolean correct = true;
        
        try
        { 
            /* this section should come before parse / catch trigger
               even a correct parse statement may stop this check  */
            if (phone.length() != 10)
            correct = false; // if character count != 10
            
            int testPhone1 = Integer.parseInt(phone.substring(0, 6)); 
            int testPhone2 = Integer.parseInt(phone.substring(7, 10));
        } 
        catch(NumberFormatException e)
        {   
            System.out.print("PARSE EXCEPTION = " + e);
            correct = false; // if not an integer / long 
        }
        finally
        {
        return correct;
        }
    }
    
    
    
    // ---------- check customer/patient password format
    public boolean checkPw(String password)
    { 
        boolean correct = true;
        
        try
        {
            /* this section should come before parse / catch trigger
               even a correct parse statement may stop this check  */
            if (password.length() != 4)
            correct = false; // if character count != 4  
            
            int testPw = Integer.parseInt(password); // is integer?       
        }
        catch(NumberFormatException e)
        {           
           System.out.print("PARSE EXCEPTION = " + e);
           correct = false; // if not an integer
        }
        finally
        {
        return correct;
        }
    }
    
    
    
    // ----- format date for HTML -----
    public String formatDate(String day)
    { 
        // extract date
        String dateFormatted = day.substring(0, 10);
        
        return dateFormatted;
    }
    
    
    // ----- format date for HTML -----
    public String formatDateSubmit(String day)
    { 
        // extract date
        String dateFormatted = day.substring(0, 10);
        // conform to ISO 8601 standard
        dateFormatted += " 00:00:00"; 
        
        return dateFormatted;
    }
    
    
    
    // ---------- format time for HTML
    public String formatTime(String time)
    { 
        
    String timeFormatted = "";    
    try{
        // parse initial value
        double whole = Math.floor(Double.valueOf(time));
        double remainder = Double.valueOf(time) - Math.floor(Double.valueOf(time));
        String frontZero = "";
        String backZero = "";
        String abbr = "";       
        String hr = "";
        String min = "";
        
        // assign abbreviation
        if (whole >= 12)
        abbr = "PM"; 
        else
        abbr = "AM"; 
        
        // convert to hours
        if (whole >= 13)
        {
            whole-=12; 
            hr = (int)whole + "";
        }
        else
        hr = (int)whole + "";        
        
        // convert to minutes
        min = (int)(Math.round(60 * remainder)) + "";   
        
        // ensure 4-digit time output
        if (whole <= 9)
        frontZero = "0";
        if (remainder <= .15)
        backZero = "0";

        // concatenate strings for return
        timeFormatted = frontZero + hr + ":" + min + backZero + " " + abbr;
        }
        catch(Exception e)
        {
           timeFormatted = "invalid time entered";
        }
        
        return timeFormatted;
    }

    
    
    // ---------- format phone number for HTML (used in Servlets)
    public String formatPhoneHtml(String phone)
    { 
        // apply pattern / format
        /* 
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
        would be better normally - but <input elements in HTML require &nbsp; for spaces.
        */
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1)&nbsp;$2-$3");
        
        return phoneFormatted;
    }
    
    
        // ---------- format phone number for HTML (used in Servlets)
    public String formatPhone(String phone)
    { 
        // apply pattern / format
        /* 
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1)&nbsp;$2-$3");
        would be better for certain fields/types that require $nbsp; for spacing
        */
        String phoneFormatted = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
        
        return phoneFormatted;
    }
    
    
    // ========== DATABASE METHODS ==========    
    
    // ----- format doctor id by adding associated name for HTML ----- 
    public String formatDoctorEntryDB(String _docId)
    { 
        String idPlusName = _docId; // new HTML presentation string. initial value
    try {           
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT DocID, DocLN, DocFN FROM Doctors WHERE DocID = '" + _docId + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            idPlusName = rs.getString(1) + " "  // concantenate chiropractor id to new string
                       + rs.getString(2) + ", " // concantenate chiropractor last name to new string
                       + rs.getString(3);       // concantenate chiropractor first name to new string 

            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    
        finally
        { return idPlusName; }
        
    }
    
    
    
        // ----- format patient id by adding associated name for HTML ----- 
    public String formatPatientEntryDB(String _patId)
    { 
        String idPlusName = _patId; // new HTML presentation string. initial value
    try {           
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT PatID, PatLN, PatFN FROM Patients WHERE PatID = '" + _patId + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            idPlusName = rs.getString(1) + " "  // concantenate chiropractor id to new string
                       + rs.getString(2) + ", " // concantenate chiropractor last name to new string
                       + rs.getString(3);       // concantenate chiropractor first name to new string 

            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    
        finally
        { return idPlusName; }
        
    }
   
    
    
    // ========== MAIN METHOD 
    public static void main(String[] args)
    {
        Formatter f1 = new Formatter();
        System.out.println("test Phone 999777020 = " + f1.checkPhone("999777020"));
    }
    
}
