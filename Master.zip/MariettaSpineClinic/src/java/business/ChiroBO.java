package business;

import java.sql.*; 
import java.text.SimpleDateFormat;
import java.util.*;

public class ChiroBO {

    private String id, pw, fName, lName, phone, email; // simple properties
    private List<AppointmentBO> apptList = new ArrayList<AppointmentBO>(); // appointment list
    private List<String> patList = new ArrayList<String>(); // patient list

    public ChiroBO() {
        id = "";
        pw = "";
        fName = "";
        lName = "";
        phone = "";
        email = "";
    } 
    public ChiroBO(String ID, String password, String firstName, String lastName, String Phone, String Email) {
        id = ID;
        pw = password;
        fName = firstName;
        lName = lastName;
        phone = Phone;
        email = Email; 
    }
    
    public void setChiroId(String i) {
        id = i; 
    }
    public String getChiroId(){
        return id; 
    }
    
    public void setChiroPw(String pas)  {
        pw = pas;
    }
    public String getChiroPw(){
        return pw;
    }

    public void setChiroFn(String fn) {
        fName = fn;
    }
    public String getChiroFn(){
        return fName;
    }

    public void setChiroLn(String ln) {
        lName = ln;
    }
    public String getChiroLn(){
        return lName;
    }

    public void setChiroPhone(String n) {
        phone = n;
    }
    public String getChiroPhone() {
        return phone;
    }

    public void setChiroEmail(String e) {
        email = e;
    }
    public String getChiroEmail() {
        return email;
    }
    
    public List<AppointmentBO> getApptList(){ return apptList; } // get appointments list
    
    public List<String> getPatList(){ return patList; } // get patients list
    
    
    public String findName(String custid)
    {         
        // look up client information
        String fullName = "";
        ClientBO c1 = new ClientBO();
        c1.selectDB(custid);
        
        // concatenate final return string
        fullName = c1.getCustLn() + ", " + c1.getCustFn();
        
        return fullName;
    }
    
    
    public String formatTime(String time)
    { 
        
    String timeFormatted = "";    
    try{
        // parse initial value
        double whole = Math.floor(Double.valueOf(time));
        double remainder = Double.valueOf(time) - Math.floor(Double.valueOf(time));
        String frontZero = "";
        String backZero = "";
        String abbr = "";       
        String hr = "";
        String min = "";
        
        // assign abbreviation
        if (whole >= 12)
        { 
            abbr = "PM"; 
        }
        else
        { abbr = "AM"; } 
        
        // convert to hours
        if (whole >= 13)
        {
            whole-=12; 
            hr = (int)whole + "";
        }
        else
        {
           hr = (int)whole + "";
        }
        
        // convert to minutes
        min = (int)(Math.round(60 * remainder)) + "";   
        
        // ensure 4-digit time output
        if (whole <= 9)
        frontZero = "0";
        if (((int)(Math.round(60 * remainder))) <= 9)
        backZero = "0";

        // concatenate strings for return
        timeFormatted = frontZero + hr + ":" + min + backZero + " " + abbr;
        }
        catch(Exception e)
        {
           timeFormatted = "invalid time entered";
        }
        
        return timeFormatted;
    }
    
    
    public String formatDay(String day)
    { 
        // extract date
        String date = day.substring(0, 10);
        
        return date;
    }
    
    
    
    // Print. Appointments List
    public void printApptList()
    {
        System.out.println("\n" + "======== Printing Appointment List...");
        for(AppointmentBO appt:apptList)  
        appt.display(); 
    }        
    
    
    // Print. Patients List
    public void printPatList()
    {
        System.out.println("\n" + "======== Printing Patients List...");
        for(String pat:patList)  
        System.out.println(pat); 
    }   
    
    
    /******************************
     * logs the list of appointments 
     * 
     *******************************/
    public void logApptListDB()
    {
        try // try block
        {
            System.out.println("\n" + "======== Logging Account List...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT * FROM Appointments WHERE ChiroID = '" + getChiroId() + "'";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            
            // create patient list indicators
            String clientName = "";
            boolean clientDuplicate = false;
            
            while (rs.next()) // check cursor position
            {
                
            // establish client name for later use
            clientName = findName(rs.getString(1));
             
            // create and assign Database values to new AppointmentBO object            
            AppointmentBO appt = new AppointmentBO(
                clientName, // Customer ID 
                rs.getString(2), // Chiropracotr ID
                formatDay(rs.getString(3)), // Day
                formatTime(rs.getString(4)), // Time In
                formatTime(rs.getString(5)) // Time Out
                );

            // add AppointmentBO object to object list
            apptList.add(appt);
            
            // check Patient list for Client duplicates
            for (String pat:patList)
            {
                if (pat.equals(clientName))
                clientDuplicate = true;
            }
            // add Client name to Patient string list - if no duplicates
            if (clientDuplicate == false)
            patList.add(clientName);

            
            
            }
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block
        
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks
    } // end of get chiroprator list
    
    
    
    
    
    /******************************
     * selects a chiropractor from the database 
     * 
     *******************************/

    public void selectDB(String i) {
        id = i;
        try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
                Connection con = DriverManager.getConnection(databaseURL) ;
                System.out.println("first step db connection");
                Statement stmt = con.createStatement();
                ResultSet rs;
                System.out.println("DB Connected");
                String sql = "select * from Chiropractors where ChiroID ='"+i+"'";
                System.out.println(sql);
                rs = stmt.executeQuery(sql);
                rs.next();
                setChiroId(rs.getString(1));
                setChiroPw(rs.getString(2));
                setChiroFn(rs.getString(3));
                setChiroLn(rs.getString(4));
                setChiroPhone(rs.getString(5));
                setChiroEmail(rs.getString(6));
        }
        catch(Exception e) {
            System.out.println(e);
        }
    }
    /******************************************
     * insert adds a new chiropractor to the database 
     * 
     *****************************************/
    
    
    
    public void insertDB(String ID, String PW, String Fn, String Ln, String Phone, String Email) {
        id = ID;
        pw = PW;
        fName = Fn;
        lName = Ln;
        phone = Phone;
        email = Email;
        
        try {
            
            String databaseURL = "jdbc:ucanaccess://C://Users/csywa/Desktop/AdvanceSystemsProj/MariettaSpineClinicMDB.mdb/";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("first step db connection");
            Statement stmt = con.createStatement();
            ResultSet rs;
            System.out.println("DB Connected");
            String sql = "Insert into Chiropractors values('"+getChiroId()+"',"+ 
                                                      "'"+getChiroPw()+"',"+ 
                                                      "'"+getChiroFn()+"',"+
                                                      "'"+getChiroLn()+"',"+
                                                      "'"+getChiroPhone()+"',"+
                                                      "'"+getChiroEmail()+"')";
            System.out.println(sql);
            stmt.execute(sql);
            
        }
        catch(Exception e) {
            System.out.println(e);
        }  
    }
    
    /********************************************
     * Delete removes a chiropractors information from the database
     * 
     ********************************************/
    
    public void deleteBO() {
        try {
            String databaseURL = "jdbc:ucanaccess://C://Users/csywa/Desktop/AdvanceSystemsProj/MariettaSpineClinicMDB.mdb/";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("Delete Connected");
            Statement stmt = con.createStatement();
            String sql = "Delete from Chiropractors where ChiroID='"+getChiroId()+"'";
            stmt.execute(sql);
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void updateDB() {
        String fName = "Thomas";
        try {
            String databaseURL = "jdbc:ucanaccess://C://Users/csywa/Desktop/AdvanceSystemsProj/MariettaSpineClinicMDB.mdb/";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("Delete Connected");
            Statement stmt = con.createStatement();
            String sql = "update Chiropractors set ChiroID = '"+getChiroId() + "',"+ 
                                            " ChiroPW ='"+getChiroPw()+"',"+
                                            " ChiroFN ='"+fName+"',"+  
                                            " ChiroLN ='"+getChiroLn()+"',"+
                                            " ChiroPhone ='"+getChiroPhone()+"',"+
                                            " ChiroEmail = "+getChiroEmail() +
                                            " WHERE ChiroID='"+getChiroId()+"'";                                        
            System.out.println(sql);
            stmt.executeUpdate(sql);
            
        }
        catch(Exception e) {
            System.out.println(e);
        }
    }
    

    
    /**************************************
     * displays information about chiropractor
     * 
     ***************************************/
    
    public void display() {
        System.out.println("Chiropractor ID :                   "+ getChiroId());
        System.out.println("Chiropractor PW :                   "+ getChiroPw());
        System.out.println("Chiropractor First Name             "+ getChiroFn());
        System.out.println("Chiropractor Last Name              "+ getChiroLn());
        System.out.println("Chiropractor Phone                  "+ getChiroPhone());
        System.out.println("Chiropractor Email                  "+ getChiroEmail());
        System.out.println("========================================================");

    }

    public static void main(String[] args) {
        ChiroBO c1 = new ChiroBO();
        c1.selectDB("2002");
        c1.logApptListDB();        
        c1.printApptList();
        c1.printPatList();
        
        /*        
        ChiroBO c2 = new ChiroBO();
        c2.insertDB("2500", "123456", "leo", "Johnson", "6781234567", "email@dctor.com");
        c2.display();
        

        ChiroBO c3 = new ChiroBO();
        c3.selectDB("2500");
        c3.deleteBO();

        
        ChiroBO c3 = new ChiroBO();
        c1.selectDB("2000");
        c1.updateDB();
        */        


    }

}