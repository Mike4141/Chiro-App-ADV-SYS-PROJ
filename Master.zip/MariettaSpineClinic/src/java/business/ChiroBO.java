package business;

import java.sql.*; 
import java.util.*;

public class ChiroBO {

    private String id, pw, fName, lName, phone, email; // simple properties
    private List<AppointmentBO> apptList = new ArrayList<AppointmentBO>(); // appointment list (for HTML display)
    private List<String> patList = new ArrayList<String>(); // patient list (for HTML display)
    private List<String> dayList = new ArrayList<String>(); // date list (for HTML display)

    public ChiroBO() {
        id = "";
        pw = "";
        fName = "";
        lName = "";
        phone = "";
        email = "";
    } 
    public ChiroBO(String ID, String password, String firstName, String lastName, String Phone, String Email) {
        id = ID;
        pw = password;
        fName = firstName;
        lName = lastName;
        phone = Phone;
        email = Email; 
    }
    
    public void setChiroId(String i) {
        id = i; 
    }
    public String getChiroId(){
        return id; 
    }
    
    public void setChiroPw(String pas)  {
        pw = pas;
    }
    public String getChiroPw(){
        return pw;
    }

    public void setChiroFn(String fn) {
        fName = fn;
    }
    public String getChiroFn(){
        return fName;
    }

    public void setChiroLn(String ln) {
        lName = ln;
    }
    public String getChiroLn(){
        return lName;
    }

    public void setChiroPhone(String n) {
        phone = n;
    }
    public String getChiroPhone() {
        return phone;
    }

    public void setChiroEmail(String e) {
        email = e;
    }
    public String getChiroEmail() {
        return email;
    }
    
    public List<AppointmentBO> getApptList(){ return apptList; } // get appointments list
    
    public List<String> getPatList(){ return patList; } // get patient list
    
    public List<String> getDayList(){ return dayList; } // get day list   
    
    
    
    // Print. Appointments List
    public void printApptList()
    {
        System.out.println("\n" + "======== Printing Appointment List...");
        for(AppointmentBO appt:apptList)  
        appt.display(); 
    }        
    
    
    // Print. Patients List
    public void printPatList()
    {
        System.out.println("\n" + "======== Printing Patients List...");
        for(String pat:patList)  
        System.out.println(pat); 
    }   
    
    
    
        // Print. Patients List
    public void printDayList()
    {
        System.out.println("\n" + "======== Printing Date List...");
        for(String day:dayList)  
        System.out.println(day); 
    }   
    
    
    /******************************
     * logs the list of appointments 
     * 
     *******************************/
    public void logListsDB()
    {
        try // try block
        {
            System.out.println("\n" + "======== Logging Account List...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT * FROM Appointments WHERE ChiroID = '" + getChiroId() + "' ORDER BY Day";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data  
            while (rs.next()) // check cursor position
            {
            // create patient and day list indicators
            boolean patientDuplicate = false;
            boolean dayDuplicate = false;  
            // defined here, for later use in creating patient list
            String customerID = rs.getString(1); 
                            
            // create and assign Database values to new AppointmentBO object            
            AppointmentBO appt = new AppointmentBO(
                customerID, // Customer ID 
                rs.getString(2), // Chiropracotr ID
                rs.getString(3), // Day
                rs.getString(4), // Time In
                rs.getString(5) // Time Out
                );

            // add AppointmentBO object to object list
            apptList.add(appt);
            
            // check Patient list for Client duplicates
            for (String pat:patList)
            {
                if (pat.equals(appt.getCustID()))
                patientDuplicate = true;
            }
            // add Client name to Patient string list - if no duplicates
            if (patientDuplicate == false)
            patList.add(appt.getCustID());
            
            
            // check Day list for Day duplicates
            for (String day:dayList)
            {
                if (day.equals(appt.getDay()))
                dayDuplicate = true;
            }
            // add Date name to day string list - if no duplicates
            if (dayDuplicate == false)
            dayList.add(appt.getDay());  
            
            
            }
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block
        
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks
    } // end of get chiroprator list   
    
    
    
    /******************************
     * selects a chiropractor from the database 
     * 
     *******************************/

    public void selectDB(String i) {
        id = i;
        try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
                Connection con = DriverManager.getConnection(databaseURL) ;
                System.out.println("first step db connection");
                Statement stmt = con.createStatement();
                ResultSet rs;
                System.out.println("DB Connected");
                String sql = "select * from Chiropractors where ChiroID ='"+i+"'";
                System.out.println(sql);
                rs = stmt.executeQuery(sql);
                rs.next();
                setChiroId(rs.getString(1));
                setChiroPw(rs.getString(2));
                setChiroFn(rs.getString(3));
                setChiroLn(rs.getString(4));
                setChiroPhone(rs.getString(5));
                setChiroEmail(rs.getString(6));
        }
        catch(Exception e) {
            System.out.println(e);
        }
    }
    
    
     /******************************
     * updates a chiropractor from the database 
     * 
     *******************************/
    
    public void updateDB() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("Connected");
            Statement stmt = con.createStatement();
            String sql = "update Chiropractors set ChiroID = '"+getChiroId() + "',"+ 
                                            " ChiroPW ='"+getChiroPw()+"',"+
                                            " ChiroFN ='"+getChiroFn()+"',"+  
                                            " ChiroLN ='"+getChiroLn()+"',"+
                                            " ChiroPhone ='"+getChiroPhone()+"',"+
                                            " ChiroEmail = '"+getChiroEmail()+"'"+
                                            " WHERE ChiroID='"+getChiroId()+"'";                                        
            System.out.println(sql);
            stmt.executeUpdate(sql);
            
        }
        catch(Exception e) {
            System.out.println(e);
        }
    }
    

    
    /**************************************
     * displays information about chiropractor
     * 
     ***************************************/
    
    public void display() {
        System.out.println("Chiropractor ID :                   "+ getChiroId());
        System.out.println("Chiropractor PW :                   "+ getChiroPw());
        System.out.println("Chiropractor First Name             "+ getChiroFn());
        System.out.println("Chiropractor Last Name              "+ getChiroLn());
        System.out.println("Chiropractor Phone                  "+ getChiroPhone());
        System.out.println("Chiropractor Email                  "+ getChiroEmail());
        System.out.println("========================================================");

    }

    public static void main(String[] args) {
        ChiroBO c1 = new ChiroBO();
        c1.selectDB("2003");
        c1.setChiroPhone("9998887777");
        c1.updateDB();

    }

}