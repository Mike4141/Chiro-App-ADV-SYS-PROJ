package business;

import java.sql.*;
import java.util.*;
import java.time.*;

/*****************
 *Jefferson Behrens
 *CustAccts
 *Systems Project
 */
public class PatientBO {
   

    // ========== PROPERTIES ==========
    private String patId, patPw, patFn, patLn, patStreet, patCity, 
    patState, patZip, patPhone, patEmail, patInsurer, patPolicyNo; // simple properties
    private ArrayList<String> docList = new ArrayList<>(); // doctor list (for available appointments)     
    private ArrayList<String> dateList = new ArrayList<>(); // date list (for available appointments)
    private ArrayList<AppointmentBO> apptList = new ArrayList<>(); // all patient appointments
    private ArrayList<AppointmentBO> upcomingApptList = new ArrayList<>(); // patient appointments after current local date
    private ArrayList<AppointmentBO> previousApptList = new ArrayList<>(); // patient appointments after current local date 
    private ArrayList<AppointmentBO> availableApptList = new ArrayList<>(); // appointments available for patient
    //
    private AppointmentBO appointment; // appointment business object
    private ScheduleBO schedule; // schedule business object
    private DoctorBO doctor; // doctor busines object
    private LocalDate date; // appointment date

    
    
        
    // ========== CONSTRUCTOR ==========
    
    // ----- Clear -----
    public PatientBO() 
    {
        patId = "";
        patPw = "";        
        patFn = "";
        patLn = "";
        patStreet = "";
        patCity = "";
        patState = "";
        patZip = "";
        patPhone = "";
        patEmail = "";
        patInsurer = "";
        patPolicyNo = "";
        docList = new ArrayList<>();     
        dateList = new ArrayList<>();
        apptList = new ArrayList<>();
        upcomingApptList = new ArrayList<>(); 
        previousApptList = new ArrayList<>();
        availableApptList = new ArrayList<>();
    }
    
    // ----- Assign -----
    public PatientBO(String _patId, String _patPw, String _patFn, String _patLn, 
                     String _patStreet, String _patCity, String _patState, String _patZip, 
                     String _patPhone, String _patEmail, String _patInsurer, String _patPolicyNo) 
    {
        patId = _patId;
        patPw = _patPw;
        patFn = _patFn;
        patLn = _patLn;
        patStreet = _patStreet;
        patCity = _patCity;
        patState = _patState;
        patZip = _patZip;
        patPhone = _patPhone;
        patEmail = _patEmail;
        patInsurer = _patInsurer;
        patPolicyNo = _patPolicyNo;
    }
    
    
    
    
    // ========== GET / SET METHODS ==========
    
    // ----- Get / Set. Patient ID -----
    public void setPatId(String value) {patId = value;}
    public String getPatId() {return patId;}
    
    // ----- Get / Set. Patient Password -----
    public void setPatPw(String value) {patPw = value;}
    public String getPatPw() {return patPw;}
    
    // ----- Get / Set. Patient First Name -----
    public void setPatFn(String value) {patFn = value;}
    public String getPatFn() {return patFn;}
    
    // ----- Get / Set. Patient Last Name -----
    public void setPatLn(String value) {patLn = value;}
    public String getPatLn() {return patLn;}
    
    // ----- Get / Set. Patient Street -----
    public void setPatStreet(String value) {patStreet = value;}
    public String getPatStreet() {return patStreet;}
    
    // ----- Get / Set. Patient City -----
    public void setPatCity(String value) {patCity = value;}
    public String getPatCity() {return patCity;}
    
    // ----- Get / Set. Patient State -----
    public void setPatState(String value) {patState = value;}
    public String getPatState() {return patState;}
    
    // ----- Get / Set. Patient Zip -----
    public void setPatZip(String value) {patZip = value;}
    public String getPatZip() {return patZip;}
    
    // ----- Get / Set. Patient Phone -----
    public void setPatPhone(String value) {patPhone = value;}
    public String getPatPhone() {return patPhone;}
    
    // ----- Get / Set. Patient Email -----
    public void setPatEmail(String value) {patEmail = value;}
    public String getPatEmail() {return patEmail;}    
    
    // ----- Get / Set. Patient Insurance -----
    public void setPatInsurer(String value) {patInsurer = value;}
    public String getPatInsurer() {return patInsurer;}   
    
    // ----- Get / Set. Patient Policy Number -----
    public void setPatPolicyNo(String value) {patPolicyNo = value;}
    public String getPatPolicyNo() {return patPolicyNo;}  
    
    // ----- Get. Patient Doctor List (for available appointments)  -----
    public ArrayList<String> getDocList() { return docList; }    
    
    // ----- Get. Patient Date List (for available appointments)  -----
    public ArrayList<String> getDateList() { return dateList; }
    
    // ----- Get. Patient Appointment List -----
    public ArrayList<AppointmentBO> getApptList() { return apptList; }
    
    // ----- Get. Patient Previous Appointment List -----
    public ArrayList<AppointmentBO> getPreviousApptList() { return previousApptList; }
    
    // ----- Get. Patient Upcoming Appointment List -----
    public ArrayList<AppointmentBO> getUpcomingApptList() { return upcomingApptList; }
    
    // ----- Get. Patient Available Appointment List -----
    public ArrayList<AppointmentBO> getAvailableApptList() { return availableApptList; }
    
    
    
    // ========== DATABASE METHODS
    
    /* ----- Loads the Appointment and Account Lists for
     the selected doctor. Placed within selectDB method
     in order to run when Patient ID is selected ----- */ 
    public void loadListsDB()
    {
    // clear lists
    docList = new ArrayList<>();     
    dateList = new ArrayList<>();
    apptList = new ArrayList<>();    
    upcomingApptList = new ArrayList<>(); 
    previousApptList = new ArrayList<>();  
    availableApptList = new ArrayList<>();    
        try // try block
        {
            System.out.println("\n" + "======== Loadings Lists...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT PatID, DocID, Day, TimeIn, TimeOut FROM Appointments WHERE PatID ='" + getPatId() + "' ORDER BY Day, TimeIn";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
                // create appointment object via database            
                appointment = new AppointmentBO(
                rs.getString(1), // Patient ID 
                rs.getString(2), // Doctor ID
                rs.getString(3), // Day
                rs.getString(4), // Time In
                rs.getString(5)  // Time Out
                );
                
                // extract the date portion of ISO 8601 standard date and time
                date = LocalDate.parse(appointment.getDay().substring(0, 10));
                
                // ----- create appointment list -----
                // add appointment object to complete appointment list
                apptList.add(appointment);   
            
                // ----- create upcoming appointment list -----
                // add appointment object to upcoming appointment list      
                if (LocalDate.now().isBefore(date) || LocalDate.now().isEqual(date))
                upcomingApptList.add(appointment); 
                
                // ----- create previous appointment list -----
                // add appointment object to previous appointment list          
                if (LocalDate.now().isAfter(date))
                previousApptList.add(appointment);
            }
            /*ensures that most recent appointments are 
              are ordered first after while statement */
            Collections.reverse(previousApptList);
            
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
            
            // ----- NEW SQL QUERY. LOAD AVAILABLE APPOINTMENT LIST -----
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement            
            sql = "SELECT DocID, Day, TimeIn, TimeOut FROM Schedule";            
            System.out.println(sql);                        
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
                // create schedule object via database
                schedule = new ScheduleBO(
                rs.getString(1), // Doctor ID 
                rs.getString(2), // Day
                rs.getString(3), // Time In
                rs.getString(4)  // Time Out
                );                
                
                // add schedule object information to complete appointment list
                int timeIn = (int)Math.ceil(Double.parseDouble(schedule.getTimeIn()));
                int timeOut = (int)Math.floor(Double.parseDouble(schedule.getTimeOut()));
                
                for(int i = timeIn; i < timeOut; i++)
                {
                    double e = ((double)i) + .5;
                    appointment =  new AppointmentBO(
                    getPatId(), // Patient ID 
                    schedule.getDocId(), // Doctor ID 
                    schedule.getDay(), // Day
                    String.valueOf(i), // Time In
                    String.valueOf(e)  // Time Out
                    ); 
                
                    boolean availableAppt = true;
                    for(AppointmentBO appt:upcomingApptList)
                    {
                        // doctor availability check
                        if (appointment.getDocId().equals(appt.getDocId()) 
                         && appointment.getDay().equals(appt.getDay())
                         && Double.parseDouble(appointment.getTimeIn()) == Double.parseDouble(appt.getTimeIn()))
                        availableAppt = false;
                        
                        // one appointment for patient a day check?

                    }
                    // ----- create available appointment list -----
                    if (availableAppt == true)
                    availableApptList.add(appointment);
                }                   
                
                
                // ----- create doctor list -----
                // add doctor object to doctor list
                // check list for duplicate doctor 
                boolean addDoc = true;                    
                for(String doc:docList)
                { 
                    if (appointment.getDocId().equals(doc))
                    addDoc = false;
                }
                // add doctor to doctor list
                if (addDoc == true)
                docList.add(appointment.getDocId());
                
                
                // ----- create date list -----
                // check list for duplicate dates                       
                boolean addDay = true;                    
                for(String day:dateList)
                { 
                    if (appointment.getDay().equals(day))
                    addDay = false;
                }
                // add date string to date list
                if (addDay == true)
                dateList.add(appointment.getDay());
            }             
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks 
    }   
    
        
    // ----- Select. Patient with Patient ID
    public void selectDB(String _patientId) {
    try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");            
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("DB Connected");            
            Statement stmt = con.createStatement();
            String sql;
            sql = "SELECT * FROM Patients WHERE PatID = '" + _patientId +"'";
            System.out.println(sql);
                ResultSet rs;
                rs = stmt.executeQuery(sql);
                rs.next();
                setPatId(rs.getString(1));
                setPatPw(rs.getString(2));
                setPatFn(rs.getString(3));
                setPatLn(rs.getString(4));
                setPatStreet(rs.getString(5));   
                setPatCity(rs.getString(6));
                setPatState(rs.getString(7));  
                setPatZip(rs.getString(8));     
                setPatPhone(rs.getString(9));
                setPatEmail(rs.getString(10));
                setPatInsurer(rs.getString(11));
                setPatPolicyNo(rs.getString(12));
                
                con.close();
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks   
        
        // load patient lists
        loadListsDB(); 
    }
    
    
    // ----- Insert. Patient with Parameters
    public void insertDB(String _patId, String _patPw, String _patFn, String _patLn, 
                     String _patStreet, String _patCity, String _patState, String _patZip, 
                     String _patPhone, String _patEmail, String _patInsurer, String _patPolicyNo) {
        patId = _patId;
        patPw = _patPw;
        patFn = _patFn;
        patLn = _patLn;
        patStreet = _patStreet;
        patCity = _patCity;
        patState = _patState;
        patPhone = _patPhone;
        patZip = _patZip;
        patEmail = _patEmail;
        patInsurer = _patInsurer;
        patPolicyNo = _patPolicyNo;
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            Statement stmt = con.createStatement();
            String sql = "Insert into Patients values('"+getPatId()+"',"+
                                                      "'"+getPatPw()+"',"+ 
                                                      "'"+getPatFn()+"',"+
                                                      "'"+getPatLn()+"',"+
                                                      "'"+getPatStreet()+"',"+
                                                      "'"+getPatCity()+"',"+
                                                      "'"+getPatState()+"',"+
                                                      "'"+getPatZip()+"',"+
                                                      "'"+getPatPhone()+"',"+
                                                      "'"+getPatEmail()+"',"+
                                                      "'"+getPatInsurer()+"',"+
                                                          getPatPolicyNo()+")"; 
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            con.close();
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }
    
    
    // ----- Delete. Patient with Patient ID Property
    public void deleteDB(){
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            
            Statement stmt = con.createStatement();
            String sql = "Delete from Patients where PatID='"+getPatId()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("DELETE Successful!!!");
            else
                System.out.println("DELETE FAILED***********");
            con.close();
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }
    
    
    // ----- Update. Patient with Properties
    public void updateDB(){
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            
            Statement stmt = con.createStatement();
            String sql = "Update Patients set PatID = '"+getPatId() +"',"+
                                            " PatFN = '"+getPatPw()+"',"+
                                            " PatFN = '"+getPatFn()+"',"+
                                            " PatLN = '"+getPatLn()+"',"+
                                            " PatStreet = '"+getPatStreet()+"',"+
                                            " PatCity = '"+getPatCity()+"',"+
                                            " PatState = '"+getPatState()+"',"+
                                            " PatZip = '"+getPatZip()+"',"+
                                            " PatPhone = "+getPatPhone()+""+
                                            " PatEmail = '"+getPatEmail()+"',"+                                            
                                            " Insurance = "+getPatInsurer()+""+
                                            " PolicyNo = "+getPatPolicyNo()+""+
                                            " where PatID= '"+getPatId()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("UPDATE Successful!!!");
            else
                System.out.println("UPDATE FAILED***********");
            con.close();
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }
    
    
    
    // ========= PRINT METHOD
    public void print() 
    {
        System.out.println("Patient ID        :     " + getPatId());
        System.out.println("Patient Password  :     " + getPatPw());
        System.out.println("Patient FirstName :     " + getPatFn());
        System.out.println("Patient LastName  :     " + getPatLn());
        System.out.println("Patient Street    :     " + getPatStreet());
        System.out.println("Patient City      :     " + getPatCity());
        System.out.println("Patient State     :     " + getPatState());
        System.out.println("Patient Zip       :     " + getPatZip());
        System.out.println("Patient Phone     :     " + getPatPhone());
        System.out.println("Patient Email     :     " + getPatEmail());
        System.out.println("Patient Insurance :     " + getPatInsurer());
        System.out.println("Patient Policy #  :     " + getPatPolicyNo());
        System.out.println("=============================");
        
        
        System.out.println("APPOINTMENT LIST [FULL]=========");
        for(AppointmentBO appt:apptList)
        appt.print();
        
        System.out.println("APPOINTMENT LIST [UPCOMING]=========");
        for(AppointmentBO appt:upcomingApptList)
        appt.print();
        
        System.out.println("APPOINTMENT LIST [PREVIOUS]=========");
        for(AppointmentBO appt:previousApptList)
        appt.print();
        
        System.out.println("AVAIABLE APPOINTMENT LIST [FULL]==============");
        for(AppointmentBO appt:availableApptList)
        appt.print();
        
        System.out.println("DOCTOR LIST [MADE FROM AVAIL. APPT LIST]==============");
        for(String doc:docList)
        System.out.println(doc);
        
        System.out.println("DATE LIST [MADE FROM AVAIL. APPT LIST]=========");
        for(String date:dateList)
        System.out.println(date);
    }
    

    // ========== MAIN METHOD
    public static void main(String[] args) {
        PatientBO  p1 = new PatientBO();
        p1.selectDB("3001");
        p1.print();
    }
}