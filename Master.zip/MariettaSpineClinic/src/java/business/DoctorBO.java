package business;

import java.sql.*; 
import java.time.*;
import java.util.*;

public class DoctorBO {

    
    // ========== PROPERTIES ==========
    private String docId, docPw, docFn, docLn, docPhone, docEmail; // simple properties
    private ArrayList<String> dateList = new ArrayList<>(); // date list (for upcoming appointments)
    private ArrayList<PatientBO> patList = new ArrayList<>(); // patient list (for all doctor appointments) 
    private ArrayList<AppointmentBO> apptList = new ArrayList<>(); // all doctor appointments
    private ArrayList<AppointmentBO> upcomingApptList = new ArrayList<>(); // doctor appointments after current local date
    private ArrayList<AppointmentBO> previousApptList = new ArrayList<>(); // doctor appointments after current local date   
    //
    private AppointmentBO appointment; // appointment business object    
    private PatientBO patient; // patient busines object
    private LocalDate date; // appointment date
    
    
    
    
    // ========== CONSTRUCTORS ==========
    
    // ----- Clear -----
    public DoctorBO() 
    {
        docId = "";
        docPw = "";
        docFn = "";
        docLn = "";
        docPhone = "";
        docEmail = "";
        dateList = new ArrayList<>();
        patList = new ArrayList<>();
        apptList = new ArrayList<>(); 
        upcomingApptList = new ArrayList<>(); 
        previousApptList = new ArrayList<>();    
    } 
    
    // ----- Assign -----
    public DoctorBO(String _docId, String _docPw, String _docFn, String _docLn, String _docPhone, String _docEmail) 
    {
        docId = _docId;
        docPw = _docPw;
        docFn = _docFn;
        docLn = _docLn;
        docPhone = _docPhone;
        docEmail = _docEmail; 
    }
    
    
    
    
    // ========== GET / SET METHODS ==========
    
    // ----- Get / Set. Doctor ID -----
    public void setDocId(String value) { docId = value; }
    public String getDocId() { return docId; }
    
    // ----- Get / Set. Doctor Password -----
    public void setDocPw(String value) { docPw = value; }
    public String getDocPw() { return docPw; }

    // ----- Get / Set. Doctor First Name -----
    public void setDocFn(String value) { docFn = value; }
    public String getDocFn() { return docFn; }

    // ----- Get / Set. Doctor Last Name -----
    public void setDocLn(String value) { docLn = value; }
    public String getDocLn() { return docLn; }

    // ----- Get / Set. Doctor Phone -----
    public void setDocPhone(String value) { docPhone = value; }
    public String getDocPhone() { return docPhone; }

    // ----- Get / Set. Doctor Email -----
    public void setDocEmail(String value) { docEmail = value; }
    public String getDocEmail() { return docEmail; }
    
    // ----- Get. Doctor Patient List -----
    public ArrayList<String> getDateList() { return dateList; }
    
    // ----- Get. Doctor Patient List -----
    public ArrayList<PatientBO> getPatList() { return patList; }

    // ----- Get. Doctor Appointment List -----
    public ArrayList<AppointmentBO> getApptList() { return apptList; }
    
    // ----- Get. Doctor Previous (to current local day) Appointment List -----
    public ArrayList<AppointmentBO> getPreviousApptList() { return previousApptList; }
    
    // ----- Get. Doctor Upcoming (to current local day) Appointment List -----
    public ArrayList<AppointmentBO> getUpcomingApptList() { return upcomingApptList; }

    
      
   
    // ========== DATABASE METHODS ==========
    
    /* ----- Loads the Appointment, Patient, and Day Lists 
     for the selected doctor. Placed within selectDB method
     in order to run when Doctor ID is selected ----- */
    public void loadListsDB()
    {
    // clear lists
    dateList = new ArrayList<>();
    patList = new ArrayList<>();
    apptList = new ArrayList<>(); 
    upcomingApptList = new ArrayList<>(); 
    previousApptList = new ArrayList<>();      
        try // try block
        {
            System.out.println("\n" + "======== Loadings Lists...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT PatID, DocID, Day, TimeIn, TimeOut FROM Appointments WHERE DocID ='" + getDocId() + "' ORDER BY Day, TimeIn";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
                // create appointment object via database            
                appointment = new AppointmentBO(
                rs.getString(1), // Patient ID 
                rs.getString(2), // Doctor ID
                rs.getString(3), // Day
                rs.getString(4), // Time In
                rs.getString(5)  // Time Out
                );

                
                // extract the date portion of ISO 8601 standard date and time
                date = LocalDate.parse(appointment.getDay().substring(0, 10));
                
                
                // ----- create patient list -----
                // add patient object to patient list
                // check list for duplicate patient 
                patient = new PatientBO();
                patient.selectDB(appointment.getPatId());
                boolean addPat = true;                    
                for(PatientBO pat:patList)
                { 
                    if (patient.getPatId().equals(pat.getPatId()))
                    addPat = false;
                }
                // add patient to patient list
                if (addPat == true)
                patList.add(patient);
                
                
                // ----- create appointment list -----
                // add appointment object to complete appointment list
                apptList.add(appointment);   
            
                
                // add appointment object to upcoming appointment list      
                if (LocalDate.now().isBefore(date) || LocalDate.now().isEqual(date))
                {
                    // ----- create upcoming appointment list -----
                    upcomingApptList.add(appointment); 
                    
                    
                    // ----- create date list -----
                    // check list for duplicate dates                       
                    boolean addDay = true;                    
                    for(String day:dateList)
                    { 
                        if (appointment.getDay().equals(day))
                        addDay = false;
                    }
                    // add date string to date list
                    if (addDay == true)
                    dateList.add(appointment.getDay());
                }
                // ----- create previous appointment list -----
                // add appointment object to previous appointment list          
                if (LocalDate.now().isAfter(date))
                previousApptList.add(appointment);
            }
            /*ensures that most recent appointments are 
              are ordered first after while statement */
            Collections.reverse(previousApptList);
            
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks 
    }     
  
    
    // ----- Select. Doctor with Doctor ID ----- 
    public void selectDB(String _doctorId) 
    {
    try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("first step db connection");
            Statement stmt = con.createStatement();
            ResultSet rs;
            System.out.println("DB Connected");
            String sql = "SELECT * FROM Doctors WHERE DocID ='" + _doctorId + "'";
            System.out.println(sql);
            rs = stmt.executeQuery(sql);
            rs.next();
            setDocId(rs.getString(1));
            setDocPw(rs.getString(2));
            setDocFn(rs.getString(3));
            setDocLn(rs.getString(4));
            setDocPhone(rs.getString(5));
            setDocEmail(rs.getString(6));
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks     
        
        // load doctor lists
        loadListsDB(); 
    }
    
    
    
    // ----- Insert. Doctor with Doctor ID ----- 
    public void insertDB(String _docId, String _docPw, String _docFn, 
                         String _docLn, String _docPhone, String _docEmail)
    {
            try{
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement                       
            String sql = "INSERT INTO Doctors values('"+_docId+"',"+
                                                    "'"+_docPw+"',"+ 
                                                    "'"+_docFn+"',"+
                                                    "'"+_docLn+"',"+
                                                    "'"+_docPhone+"',"+
                                                    "'"+_docEmail+"')"; 
            
            //step 5. process
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT SUCCESS!");
            else
            System.out.println("INSERT FAILURE!");
            
            //step 6. close connection
            con.close();
            }
            catch (Exception e)
            { System.out.println(e);}
    }    
    
    
    
    // ----- Delete. Doctor with Doctor ID -----     
    public void deleteDB(String _docId)
    {
            try{
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement                       
            String sql = "DELETE FROM Doctors WHERE DocID = '" + _docId + "'";
            
            //step 5. process
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
            System.out.println("DELETE SUCCESS!");
            else
            System.out.println("DELETE FAILURE!");
            
            //step 6. close connection
            con.close();
            }
            catch (Exception e)
            { System.out.println(e);}
    }    
    
    
      
    
    
    
    
    // ----- Update. Doctor with Properties
    public void updateDB() 
    {
    try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("Connected");
            Statement stmt = con.createStatement();
            String sql = "update Doctors set DocID = '"+getDocId() + "',"+ 
                                            " DocPW ='"+getDocPw()+"',"+
                                            " DocFN ='"+getDocFn()+"',"+  
                                            " DocLN ='"+getDocLn()+"',"+
                                            " DocPhone ='"+getDocPhone()+"',"+
                                            " DocEmail = '"+getDocEmail()+"'"+
                                            " WHERE DocID='"+getDocId()+"'";                                        
            System.out.println(sql);
            stmt.executeUpdate(sql);
            
        }
        // ----- multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks     
    }
    

    

    // ========== PRINT METHODS ==========
    
    // ----- Print. Doctor Properties -----
    public void print() 
    {
        System.out.println("Doctor ID  :     " + getDocId());
        System.out.println("Password   :     " + getDocPw());
        System.out.println("First Name :     " + getDocFn());
        System.out.println("Last Name  :     " + getDocLn());
        System.out.println("Phone #    :     " + getDocPhone());
        System.out.println("Email      :     " + getDocEmail());
        System.out.println("=============================");
        
        System.out.println("DATE LIST =========");
        for(String day:dateList)
        System.out.println(day);
        
        System.out.println("PATIENT LIST =========");
        for(PatientBO pat:patList)
        pat.print();
        
        System.out.println("APPOINTMENT LIST [FULL]=========");
        for(AppointmentBO appt:apptList)
        appt.print();
        
        System.out.println("APPOINTMENT LIST [UPCOMING]=========");
        for(AppointmentBO appt:upcomingApptList)
        appt.print();
        
        System.out.println("APPOINTMENT LIST [PREVIOUS]=========");
        for(AppointmentBO appt:previousApptList)
        appt.print();
    }
    
    
    
        
    // ========== MAIN METHOD ==========
    public static void main(String[] args) 
    {
        DoctorBO d1 = new DoctorBO();
        d1.selectDB("2001");
        d1.print();        
         /*       
        d1.insertDB("2004", "1234", "Joe", "Doe", "1234567891", "joe.doe@gmail.com");
        d1.setDocPhone("9998887777");
        d1.updateDB();
        */
    }

}