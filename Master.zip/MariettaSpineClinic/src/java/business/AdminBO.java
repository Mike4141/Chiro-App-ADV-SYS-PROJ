package business;

import java.sql.*;
import java.util.*;


public class AdminBO 
{    
    // =================== PROPERTIES ===================
    // arraylists
    private List<DoctorBO> doctorList = new ArrayList<DoctorBO>();      
    private List<ScheduleBO> scheduleList = new ArrayList<ScheduleBO>();
    // strings
    private String adminId, adminPw;
    // objects
    ScheduleBO latestShift = new ScheduleBO();
    
    
    // =================== CONSTRUCTORS ===================    
    // Empty
    public AdminBO()
    {
        adminId = "";
        adminPw = "";
        doctorList = new ArrayList<DoctorBO>();      
        scheduleList = new ArrayList<ScheduleBO>();
        latestShift = new ScheduleBO();
    }    
    // Assign
    public AdminBO(String adminid, String adminpw)
    {
        adminId = adminid;
        adminPw = adminpw;
    }
    
    
    // =================== GET / SET METHODS ===================     
    public String getAdminId(){ return adminId; } // get patient id
    public void setAdminId(String value){ adminId = value; } // set patient id
    public String getAdminPw(){ return adminPw; } // get patient password
    public void setAdminPw(String value){ adminPw = value; } // set patient password
    public List<DoctorBO> getDoctorList(){ return doctorList; } // get [FULL] doctor list
    public List<ScheduleBO> getScheduleList(){ return scheduleList; } // get [FULL] schedule list
    public void setLatestShift(ScheduleBO value){ latestShift = value; } // intended to (manually) store latest shift added
    public ScheduleBO getLatestShift(){ return latestShift; } // intended to retrieve latest shift
    
    
    // =================== PRINT METHODS ===================       
    //  Print. Chiropractor List
    public void printDoctorList()
    {
        System.out.println("\n" + "======== Printing Doctor List...");
        for(DoctorBO doc:doctorList)  
        doc.print(); 
    }        
    //  Print. Schedule
    public void printSchedule()
    {   
        System.out.println("\n" + "======== Printing Schedule Shifts...");
        for(ScheduleBO shift:scheduleList)  
        shift.print(); 
    }    
    
    //  Print. Credentials
    public void print()
    {
        System.out.println("\n" + "======== Printing Credentials...");
        System.out.println("Admin ID = " + getAdminId());
        System.out.println("Admin Password = " + getAdminPw());
        System.out.println("====================");
    }    
    
    
    // =================== DATABASE METHODS =================== 
    // ------------------- load lists --------------------
    public void loadListsDB()
    {
    doctorList = new ArrayList<DoctorBO>();      
    scheduleList = new ArrayList<ScheduleBO>();
        try // try block
        {
            System.out.println("\n" + "======== Loading Doctor List...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT * FROM Doctors";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
            // create and assign Database values to new DoctorBO objects             
            DoctorBO doctor = new DoctorBO(
                rs.getString(1), // Doctor ID 
                rs.getString(2), // Doctor Password
                rs.getString(3), // Doctor First Name
                rs.getString(4), // Doctor Last Name
                rs.getString(5), // Doctor Phone
                rs.getString(6)  // Doctor Email
                );

            // add DoctorBO object to object list
            doctorList.add(doctor);
            }
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
            
            // --------------- NEW SQL INQUIRY: LOAD SCHEDULE LIST
            
            System.out.println("\n" + "======== Loading Schedule List...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            sql = "SELECT * FROM Schedule ORDER BY Day, TimeIn";            
            System.out.println(sql);                        
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
            // create and assign Database values to new Schedule objects             
            ScheduleBO shift = new ScheduleBO(
                rs.getString(1), // Doctor ID 
                rs.getString(2), // Day
                rs.getString(3), // Time In
                rs.getString(4)  // Time Out
                );

            // add DoctorBO object to object list
            scheduleList.add(shift);
            }
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block 
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks
    } // end of load lists
        


    // -------------------- select method --------------------
    public void selectDB(String id) 
    {
    try {
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT * FROM Admins WHERE AdminID = '" + id + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            setAdminId(rs.getString(1)); // set admin id 
            setAdminPw(rs.getString(2)); // set admin password
            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
    
        // load lists
        loadListsDB();
        
        // end of catch blocks    
    } // end of select method
            
    
    
    
    // ==================== Main Method ====================
    public static void main(String[] args)
    {        
        AdminBO admin = new AdminBO();
        
        // look up and print admin credentials
        admin.selectDB("Admin07");
        admin.print();
        
    } // End of Main Method


} // End of class