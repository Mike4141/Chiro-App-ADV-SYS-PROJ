package business;

import java.sql.*;
import java.util.*;


public class AdminBO 
{    
    // =================== PROPERTIES ===================
    // arraylists
    private List<DoctorBO> chiroList = new ArrayList<DoctorBO>();      
    private List<ScheduleBO> schedule = new ArrayList<ScheduleBO>();
    // strings
    private String adminId, adminPw;
    
    
    // =================== CONSTRUCTORS ===================    
    // Empty
    public AdminBO()
    {
        adminId = "";
        adminPw = "";
    }    
    // Assign
    public AdminBO(String adminid, String adminpw)
    {
        adminId = adminid;
        adminPw = adminpw;
    }
    
    
    // =================== GET / SET METHODS ===================     
    public String getAdminId(){ return adminId; } // get customer id
    public void setAdminId(String value){ adminId = value; } // set customer id
    public String getAdminPw(){ return adminPw; } // get customer password
    public void setAdminPw(String value){ adminPw = value; } // set customer password
    public List<DoctorBO> getChiroList(){ return chiroList; } // get chiropractor list
    
    
    // =================== PRINT METHODS ===================       
    //  Print. Chiropractor List
    public void printChiroList()
    {
        System.out.println("\n" + "======== Printing Chiro List...");
        for(DoctorBO chiro:chiroList)  
        chiro.print(); 
    }        
    //  Print. Schedule
    public void printSchedule()
    {   
        System.out.println("\n" + "======== Printing Schedule Shifts...");
        for(ScheduleBO shift:schedule)  
        shift.print(); 
    }    
    
    //  Print. Credentials
    public void printCredentials()
    {
        System.out.println("\n" + "======== Printing Credentials...");
        System.out.println("Admin ID = " + getAdminId());
        System.out.println("Admin Password = " + getAdminPw());
        System.out.println("====================");
    }    
    
    
    // =================== DATABASE METHODS =================== 
    // ------------------- get chiropractor list --------------------
    public void logChiroListDB()
    {
        try // try block
        {
            System.out.println("\n" + "======== Logging Chiro List...");
            
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT * FROM Doctors WHERE Doctors IS NOT NULL";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
            // create and assign Database values to new ChiroBO object             
            DoctorBO chiro = new DoctorBO(
                rs.getString(1), // ID 
                rs.getString(2), // Password
                rs.getString(3), // First Name
                rs.getString(4), // Last Name
                rs.getString(5), // Phone
                rs.getString(6)  // Email
                );

            // add ChiroBO object to object list
            chiroList.add(chiro);
            }
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();   
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block // end of try block
        
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks
    } // end of get chiroprator list
        
    // ------------------- get schedule --------------------
    public void logScheduleDB()
    {
        try // try block
        {
            System.out.println("\n" + "======== Logging Schedule...");
                        
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement
            String sql;            
            sql = "SELECT * FROM Schedule WHERE Day IS NOT NULL";            
            System.out.println(sql);                        
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            //step 5. process data
            while (rs.next()) // check cursor position
            {
            // create and assign Database values to new ScheduleBO object             
            ScheduleBO shift = new ScheduleBO(
                rs.getString(4), // Chiropractor ID 
                rs.getString(1), // Day of the Week
                rs.getString(2), // Start Time 
                rs.getString(3)  // End Time
                );

            // add ScheduleBO object to object list
            schedule.add(shift);
            }
            System.out.println("Data Processed.");
            
            //step 6. close connection
            con.close();  
            System.out.println("Connection Closed.");
            System.out.println("====================");
            
        } // end of try block // end of try block
        
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks
    } // end of Get Schedule   

// -------------------- select method --------------------
    public void selectDB(String id) 
    {
    try {
            System.out.println("\n" + "======== SELECTING...");
            
            // step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            // step 2. get connection 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            // step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            // step 4. execute statement
            String sql;
            sql = "SELECT * FROM Admins WHERE AdminID = '" + id + "'";
            System.out.println(sql);
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            System.out.println("Statement Executed.");
            
            // step 5. process data
            rs.next();
            setAdminId(rs.getString(1)); // set admin id 
            setAdminPw(rs.getString(2)); // set admin password
            System.out.println("-SELECT SUCCESS-");
            
            // step 6. close connection
            con.close(); 
            System.out.println("Connection Closed.");
            System.out.println("====================");
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }
        // end of catch blocks    
    } // end of select method
            
    
    // ==================== Main Method ====================
    public static void main(String[] args)
    {        
        AdminBO admin = new AdminBO();
        
        // look up and print admin credentials
        admin.selectDB("Admin07");
        admin.printCredentials();
        
        // look up and print chiropractor list
        admin.logChiroListDB();
        admin.printChiroList();        

        // look up and print schedule shifts
        admin.logScheduleDB();
        admin.printSchedule();
    } // End of Main Method


} // End of class