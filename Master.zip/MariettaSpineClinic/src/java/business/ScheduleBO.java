package business;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ScheduleBO {
    
    
    // ========== PROPERTIES ==========
    private String docId, day, timeIn, timeOut;
        
    
    
    
    // ========== CONSTRUCTORS ==========
    
    // ----- Clear -----
    public ScheduleBO() 
    {
        docId = "";
        day = "";
        timeIn = "";
        timeOut = "";
    }
    
    // ----- Assign -----
    public ScheduleBO(String _docId, String _day, String _timeIn, String _timeOut) 
    {
        docId = _docId;
        day = _day;
        timeIn = _timeIn;
        timeOut = _timeOut;
    }
    
    

    
    // ========== GET / SET METHODS ==========

    // ----- Get / Set. Doctor ID ----- 
    public String getDocId() { return docId; }
    public void setDocId(String value) { this.docId = value; }

    // ----- Get / Set. Day -----
    public String getDay() { return day; }
    public void setDay(String value) { this.day = value; }

    // ----- Get / Set. Time In -----
    public String getTimeIn() { return timeIn; }
    public void setTimeIn(String value) { this.timeIn = value; }
    
    // ----- Get / Set. Time Out -----
    public String getTimeOut() { return timeOut; }
    public void setTimeOut(String value) { this.timeOut = value; }
 
    
    
    // ========== PRINT METHOD ==========
    public void print() 
    {
        System.out.println("Doctor ID  :     "+ getDocId());
        System.out.println("Date       :     "+ getDay());
        System.out.println("Time In    :     "+ getTimeIn());
        System.out.println("Time Out   :     "+ getTimeOut());
        System.out.println("=========================");
    }
    
    
    
        // ----- Select. Appointment Entry with Account Number ----- 
    public void selectDB(String _docId, String _day) 
    {
    try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            String databaseURL = "jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb";
            Connection con = DriverManager.getConnection(databaseURL) ;
            System.out.println("first step db connection");
            Statement stmt = con.createStatement();
            ResultSet rs;
            System.out.println("DB Connected");
            /* exolicitly outlining the select order 
            ensures that the information is taken in 
            the correct order despite a lack of key */
            String sql = "SELECT DocID, Day, TimeIn, TimeOut FROM Schedule WHERE DocID ='" 
                       + _docId + "' AND Day = '" + _day + "'";
            System.out.println(sql);
            rs = stmt.executeQuery(sql);
            rs.next();
            setDocId(rs.getString(1));
            setDay(rs.getString(2));
            setTimeIn(rs.getString(3));
            setTimeOut(rs.getString(4));
        }
        // multiple catch blocks
        catch (SQLException e)
        {
            System.out.println("SQL EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (ClassNotFoundException e)            
        {
            System.out.println("CLASS NOT FOUND EXCEPTION: " + e);
            System.out.println("====================");
        }
        catch (Exception e)            
        {
            System.out.println("EXCEPTION: " + e);
            System.out.println("====================");
        }// end of catch blocks  
    }
    
    
    public void insertDB(String _docId, String _date, String _timeIn, String _timeOut)
    {
            try{
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement                       
            String sql = "INSERT INTO Schedule values('"+_docId+"',"+
                                                      "'"+_date+"',"+ 
                                                      "'"+_timeIn+"',"+
                                                          _timeOut+")"; 
            
            //step 5. process
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT SUCCESS!");
            else
            System.out.println("INSERT FAILURE!");
            
            //step 6. close connection
            con.close();
            }
            catch (Exception e)
            { System.out.println(e);}
    }    
    
    
    
    
    public void deleteDB(String _docId, String _date)
    {
            try{
            //step 1. load driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("Driver Loaded.");
            
            //step 2. get connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/victo/Desktop/Files/Spring2022/Advance Systems Project/DataBase/MariettaSpineClinicMDB.mdb");
            System.out.println("Connected.");
            
            //step 3. create statement
            Statement stmt = con.createStatement();
            System.out.println("Statement Created.");
            
            //step 4. execute statement                       
            String sql = "DELETE FROM Schedule WHERE DocID = '" + _docId + "' AND Day = '" + _date + "'";
            
            //step 5. process
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
            System.out.println("DELETE SUCCESS!");
            else
            System.out.println("DELETE FAILURE!");
            
            //step 6. close connection
            con.close();
            }
            catch (Exception e)
            { System.out.println(e);}
    }    
    
        
    
   
    
    // ========== MAIN METHOD ==========
    public static void main(String[] args) 
    {        
        // sshould return something
        ScheduleBO sched = new ScheduleBO();
        sched.selectDB("2000", "2022-08-08 00:00:00");
        sched.print();
        
        // should return nothing
        sched = new ScheduleBO();
        sched.selectDB("20009", "2022-08-08 00:00:00");
        sched.print();
    }
}