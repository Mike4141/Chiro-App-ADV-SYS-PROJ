package business;

public class ScheduleBO {
    
    
    // ========== PROPERTIES ==========
    private String docId, day, timeIn, timeOut;
        
    
    
    
    // ========== CONSTRUCTORS ==========
    
    // ----- Clear -----
    public ScheduleBO() 
    {
        docId = "";
        day = "";
        timeIn = "";
        timeOut = "";
    }
    
    // ----- Assign -----
    public ScheduleBO(String _docId, String _day, String _timeIn, String _timeOut) 
    {
        docId = _docId;
        day = _day;
        timeIn = _timeIn;
        timeOut = _timeOut;
    }
    
    

    
    // ========== GET / SET METHODS ==========

    // ----- Get / Set. Doctor ID ----- 
    public String getDocId() { return docId; }
    public void setDocId(String value) { this.docId = value; }

    // ----- Get / Set. Day -----
    public String getDay() { return day; }
    public void setDay(String value) { this.day = value; }

    // ----- Get / Set. Time In -----
    public String getTimeIn() { return timeIn; }
    public void setTimeIn(String value) { this.timeIn = value; }
    
    // ----- Get / Set. Time Out -----
    public String getTimeOut() { return timeOut; }
    public void setTimeOut(String value) { this.timeOut = value; }
 
    
    
    // ========== PRINT METHOD ==========
    public void print() 
    {
        System.out.println("Doctor ID  :     "+ getDocId());
        System.out.println("Date       :     "+ getDay());
        System.out.println("Time In    :     "+ getTimeIn());
        System.out.println("Time Out   :     "+ getTimeOut());
        System.out.println("=========================");
    }
    
        
    
    
    // ========== MAIN METHOD ==========
    public static void main(String[] args) 
    {         
        // test code
    }
    
}