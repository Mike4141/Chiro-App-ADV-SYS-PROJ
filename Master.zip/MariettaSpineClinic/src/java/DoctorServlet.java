import business.AppointmentBO;
import business.DoctorBO;
import business.Formatter;
import business.PatientBO;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/DoctorServlet"})
public class DoctorServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
                        
    try{   
            
        // ++++++++++ GET TRIGGER VALUE ++++++++++
        String trigger = request.getParameter("trigger");
        if (trigger == null) trigger = "login";
        
        
        
        
        // ++++++++++ UPDATE PERSONAL INFORMATION ++++++++++ 
        if (trigger.equals("updateinfo"))
        {
            // ========== GET DOCTOR BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            DoctorBO doctor = (DoctorBO)session.getAttribute("doctor"); // get doctor object from session 
            System.out.println("Doctor Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========
            String pwGui, fnameGui, lnameGui, phoneGui, emailGui;
            pwGui = request.getParameter("showpw"); // get password from GUI
            fnameGui = request.getParameter("showfname"); // get first name from GUI
            lnameGui = request.getParameter("showlname"); // get last name from GUI
            phoneGui = request.getParameter("showphone"); // get phone from GUI
            emailGui = request.getParameter("showemail"); // get email from GUI
            Formatter format = new Formatter(); // create formatter object
            
            
            // ========== UPDATE PERSONAL INFORMATION IN DATABASE ==========  
            doctor.setDocPw(pwGui);
            doctor.setDocFn(fnameGui);
            doctor.setDocLn(lnameGui);
            doctor.setDocPhone(phoneGui);
            doctor.setDocEmail(emailGui);
            doctor.updateDB();  
            
            
            // ========== CHECK IF UPDATE TOOK EFFECT ==========
            if (doctor.getDocPw().equals(pwGui)
            && !doctor.getDocFn().equals(fnameGui)
            && !doctor.getDocLn().equals(lnameGui)
            && !doctor.getDocPhone().equals(phoneGui)
            && !doctor.getDocEmail().equals(emailGui))
            {
                // ========== re-direct to specific action error page ==========
                response.sendRedirect("doctor0infoupdate.html");
            }            
            
                        
            // ========= RE-ADD UPDATED DOCTOR BUSINESS OBJECT ==========
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("Doctor Object re-added to Session. Scheduled.");             
            
            
            // ========== RE-LOAD DOCTOR HOME PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - doctorhomepage.jsp");
        }
        
        
        
      
        // ++++++++++ CANCEL APPOINTMENT ++++++++++
        if (trigger.equals("cancel"))                
        {
            // ========== GET DOCTOR BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            DoctorBO doctor = (DoctorBO)session.getAttribute("doctor"); // get doctor object from session 
            System.out.println("Doctor Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========            
            String newApptDay, newApptTimeIn, newApptDocId;
            newApptDay = request.getParameter("readyday"); // get new appointment day from hidden input
            newApptTimeIn = request.getParameter("readytimein"); // get new appointment time in from hidden input
            newApptDocId = request.getParameter("readydocid"); // get new appointment doctor id from hidden input
            AppointmentBO endAppt = new AppointmentBO(); // new appointment object for scheduling
            Formatter format = new Formatter();
                        
            
            // CHECK IF ENTRY ALREADY EXISTS *IT SHOULD*
            endAppt.selectDB(newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn);
            if (endAppt.getDocId().equals("") 
            && endAppt.getDay().equals("")
            && endAppt.getTimeIn().equals(""))
            {
                // ========== re-direct to specific action failed page ==========
                response.sendRedirect("doctor0apptexists.html");
            }
            endAppt = new AppointmentBO(); // re-set appointment for delete
            
            
            // ========== DELETE APPOINTMENT FOR PATIENT ==========   
            endAppt.setDocId(newApptDocId);
            endAppt.setDay(format.formatDateSubmit(newApptDay));
            endAppt.setTimeIn(newApptTimeIn);
            endAppt.deleteDB();    
            endAppt = new AppointmentBO(); // re-set appointment for last check
                        
            
            // ========== CHECK IF ENTRY STILL EXISTS *IT SHOULD NOT* =========            
            endAppt.selectDB(newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn);
            if (!endAppt.getDocId().equals("") 
            && !endAppt.getDay().equals("")
            && !endAppt.getTimeIn().equals(""))
            {
                // ========== Go to generic action failed page ==========
                response.sendRedirect("actionfailed.html");
            }            
                        
            // ========== UPDATE DOCTOR AND RE-LOAD LISTS ==========
            doctor.selectDB(doctor.getDocId());           
            
            
            // ========= RE-ADD UPDATED DOCTOR BUSINESS OBJECT ==========
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("Doctor Object re-added to Session. Scheduled.");                         
            

            // ========== RE-LOAD DOCTOR HOME PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - doctorhomepage.jsp");
        }        
        
        
        
        
        // ++++++++++ LOGIN ++++++++++ 
        if (trigger.equals("login"))
        {
            // ========== PROPERTIES ==========
            
            // ----- Get ID & Password from Doctor Login Page -----
            String idGui = request.getParameter("uname"); // get id from GUI
            String pwGui = request.getParameter("psw"); // get password from GUI
            
            // ----- Get Doctor Business Object -----
            DoctorBO doctor = new DoctorBO(); // empty doctor object
            doctor.selectDB(idGui); // select doctor and load lists from database

            // ----- Get ID & Password from Database -----
            String idDb = doctor.getDocId(); //  get doctor id from database
            String pwDb = doctor.getDocPw(); // get doctor password from database                  
                     
            
            
            // ========= ADD DOCTOR BUSINESS OBJECT TO SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("Doctor Object added to Session. Scheduled.");             
            
                       
            
            // ========== CHECK ID & PASSWORD AGAINST DATABASE ==========
            if (pwGui != null && idGui != null && pwGui.equals(pwDb) && idGui.equals(idDb)) // do id and passwords match?
            {
                // ----- re-direct to doctor logged in page -----
                response.sendRedirect("doctorloggedin.html");
            }
            else
            {
                // ----- re-direct to doctor login failed page -----
                response.sendRedirect("doctorloginfailed.html");
            }
        }
        
        
        
        // ++++++++++ LOGOUT ++++++++++ 
        if (trigger.equals("logout"))
        {
            HttpSession session = request.getSession();
            if(session.getAttribute("doctor") != null)
            {
            session.removeAttribute("doctor");
            session.invalidate();
            response.sendRedirect("doctorlogin.html");                 
            }
            else
            response.sendRedirect("doctorlogin.html");      
        }
        
        
        
    }
    catch(NullPointerException e)
    {
        /* IF NULL POINTER EXCEPTION OCCURS IN SERVLET - YOU ARE LIKELY NOT
        LOGGED IN AT THE MOMENT - SO YOU WILL BE RE-DIRECTED ACCORDINGLY */
            
        // go to Doctor Home Page (session or "trigger" variable related) 
        // ----- this homepage will simply show that user is not logged in
        RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp");
        rd.include(request, response);
    }
    catch(Exception e)
    {
        // go to Unkown Error Home Page 
        RequestDispatcher rd = request.getRequestDispatcher("error.html");
        rd.include(request, response);
    } 
   
                    
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
