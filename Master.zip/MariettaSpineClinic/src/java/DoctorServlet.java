import business.DoctorBO;
import business.Formatter;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/DoctorServlet"})
public class DoctorServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
                        
        try{   
            
        // ++++++++++ GET TRIGGER VALUE ++++++++++
        String trigger = request.getParameter("trigger");
        if (trigger == null) trigger = "login";
        
        
        
        
        // ++++++++++ UPDATE PERSONAL INFORMATION ++++++++++ 
        if (trigger.equals("updateinfo"))
        {
            // ========== GET DOCTOR BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            DoctorBO doctor = (DoctorBO)session.getAttribute("doctor"); // get doctor object from session 
            System.out.println("Doctor Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========
            String pwGui, phoneGui, emailGui;
            pwGui = request.getParameter("showpw"); // get password from GUI
            phoneGui = request.getParameter("showphone"); // get phone from GUI
            emailGui = request.getParameter("showemail"); // get email from GUI
            Formatter format = new Formatter(); // create formatter object
            String passwIndColor = "gray"; // color of the password hint based on input 
            String phoneIndColor = "gray"; // color of the phone hint based on input 
            String initEditInfo = ""; // Edit mode on start up? default is "" = 'no'
            

            
            // ========== UPDATE PERSONAL INFORMATION IN DATABASE ==========  
            if (format.checkPw(pwGui) == true && format.checkPhone(phoneGui) == true)
            {
                doctor.setDocPw(pwGui);
                doctor.setDocPhone(phoneGui);
                doctor.setDocEmail(emailGui);
                doctor.updateDB();
            }
            else
            {
                // re-start page in edit mode due to incorrect user info
                initEditInfo = "editInfo()"; 
                
                // red indicators for incorrect update input format
                if (format.checkPw(pwGui) == false)
                passwIndColor = "red";
                if (format.checkPhone(phoneGui) == false)
                phoneIndColor = "red";
            }
            
            
            
            // ========= RE-ADD UPDATED DOCTOR BUSINESS OBJECT ==========
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("Doctor Object re-added to Session. Scheduled.");             
            
            

            // ========== RE-LOAD DOCTOR HOME PAGE ==========
            request.setAttribute("passwHintCol", passwIndColor);
            request.setAttribute("phoneHintCol", phoneIndColor);
            request.setAttribute("initEditInfo", initEditInfo);
            RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - doctorhomepage.jsp");
        }
        
        
        
        
        // ++++++++++ LOGIN ++++++++++ 
        if (trigger.equals("login"))
        {
            // ========== PROPERTIES ==========
            
            // ----- Get ID & Password from Doctor Login Page -----
            String idGui = request.getParameter("uname"); // get id from GUI
            String pwGui = request.getParameter("psw"); // get password from GUI
            
            // ----- Get Doctor Business Object -----
            DoctorBO doctor = new DoctorBO(); // empty doctor object
            doctor.selectDB(idGui); // select doctor and load lists from database

            // ----- Get ID & Password from Database -----
            String idDb = doctor.getDocId(); //  get doctor id from database
            String pwDb = doctor.getDocPw(); // get doctor password from database                  
                     
            
            
            // ========= ADD DOCTOR BUSINESS OBJECT TO SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("Doctor Object added to Session. Scheduled.");             
            
                       
            
            // ========== CHECK ID & PASSWORD AGAINST DATABASE ==========
            if (pwGui != null && idGui != null && pwGui.equals(pwDb) && idGui.equals(idDb)) // do id and passwords match?
            {
                    // go to Doctor home page
                    request.setAttribute("passwHintCol", "gray");
                    request.setAttribute("phoneHintCol", "gray");
                    request.setAttribute("initEditInfo", "");
                    RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
                    rd.forward(request, response); // forward request dispatcher
                    System.out.println("Webpage Loaded - doctorhomepage.jsp");
            }
            else
            {
                // sends INVALID LOGIN Prompt via HTML
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Login Failed</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Invalid Login Information.</h1>");
                out.println("</body>");
                out.println("</html>");
            }
        }
        
        
        
        // ++++++++++ LOGOUT ++++++++++ 
        if (trigger.equals("logout"))
        {
            /*
            STILL WORKING ON THIS CODE...
            
            // ========== PROPERTIES ==========             
            // ----- Get Doctor Business Object -----
            DoctorBO doctor = null; // null doctor object
                       
            
            // ========= ADD DOCTOR BUSINESS OBJECT TO SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("NULL Doctor Object added to Session. Scheduled.");       
            */
            
            // sends LOGGED OUT Prompt via HTML
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>LOGGED OUT. PLACEHOLDER</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>LOGGED OUT. PLACEHOLDER</h1>");
            out.println("</body>");
            out.println("</html>");            
        }
        
        
        
        }
        catch(NullPointerException e)
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Login Failed</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+ e +"</h1>");
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception e)
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Login Failed</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+ e +"</h1>");
            out.println("</body>");
            out.println("</html>");
        } 
   
                    
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
