/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.AdminBO;
import business.DoctorBO;
import business.Formatter;
import business.ScheduleBO;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/AdminServlet"})
public class AdminServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
                     
        try{   
            
        // ++++++++++ GET TRIGGER VALUE ++++++++++
        String trigger = request.getParameter("trigger");
        if (trigger == null) trigger = "login";
        
            
        
        // ++++++++++ LOGIN ++++++++++ 
        if (trigger.equals("login"))
        {
            // =================== Get ID & Password from Admin Login Page
            String idGui, pwGui;
            idGui = request.getParameter("uname"); // get id from GUI
            pwGui = request.getParameter("psw"); // get password from GUI
                   
            
            // =================== Get ID & Password from Database        
            AdminBO admin = new AdminBO(); // empty admin object
            admin.selectDB(idGui); // look up admin info with admin id in database
            String idDb = admin.getAdminId(); // get database id
            String pwDb = admin.getAdminPw(); // get database password  
            
            
            // =================== Put Admin Object into Session
            HttpSession session; // declare session
            session = request.getSession(); // initialize session
            session.setAttribute("admin", admin); // add admin object to session
            
            
            // =================== Check ID & Password against Database
            if (pwGui.equals(pwDb) && idGui.equals(idDb)) // do id and passwords match?
            {
                    // go to Admin Logged In Page
                    RequestDispatcher rd = request.getRequestDispatcher("adminloggedin.html");
                    rd.include(request, response);
            }
            else
            {
                // ========== Go to generic action failed page ==========
                response.sendRedirect("adminloginfailed.html");
            }
        }
        
        
        
        
        
        // ++++++++++ ADD SHIFT ++++++++++ 
        if (trigger.equals("addshift"))
        {
            // ========== GET ADMIN BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            AdminBO admin = (AdminBO)session.getAttribute("admin"); // get admin object from session 
            System.out.println("Admin Object taken from Session. Scheduled.");
            
            // ========== PROPERTIES ==========
            String idgui, dategui, timeingui, timeoutgui;
            idgui = request.getParameter("doclist");             
            dategui = request.getParameter("dateselector"); 
            timeingui = request.getParameter("timeinlist");
            timeoutgui = request.getParameter("timeoutlist");
            Formatter format = new Formatter();
            ScheduleBO schedule = new ScheduleBO();
            
            
            // ========== CHECK IF ENTRY ALREADY EXISTS *IT SHOULD NOT* ==========
            schedule.selectDB(idgui, format.formatDateSubmit(dategui));
            if (!schedule.getDocId().equals("") 
            && !schedule.getDay().equals(""))
            {
                // ----- Go to specific action failed page -----
                response.sendRedirect("admin1shift1day.html");
            }
            schedule = new ScheduleBO(); // reset for insert
            
            
            
            // ========== INSERT SHIFT ==========
            schedule.insertDB(idgui, format.formatDateSubmit(dategui), timeingui, timeoutgui);
            schedule = new ScheduleBO(); // reset for last check
                        
            
            // ========== CHECK IF EXISTS AFTER INSERT *IT SHOULD* ==========
            schedule.selectDB(idgui, format.formatDateSubmit(dategui));
            if (schedule.getDocId().equals("") 
            && schedule.getDay().equals(""))
            {
                // ----- Go to generic action failed page -----
                response.sendRedirect("actionfailed.html");
            }
            
            
            // ========== RE-LOAD LISTS ==========
            admin.selectDB(admin.getAdminId());
            
            // ========== STORE LATEST SHIFT FOR GUI ==========
            
            admin.setLatestShift(new ScheduleBO(idgui, dategui, timeingui, timeoutgui));
            
            // ========== PUT ADMIN OBJECT BACK IN SESSION ==========
            session.setAttribute("admin", admin); // re-add admin object to session   
            
            // ========== GO BACK TO ADMIN SCHEDULE PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("adminhomeschedule.jsp");
            rd.include(request, response);             
        }
        
        
        
        
        // ++++++++++ DROP SHIFT ++++++++++ 
        if (trigger.equals("dropshift"))
        {
            // ========== GET ADMIN BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            AdminBO admin = (AdminBO)session.getAttribute("admin"); // get admin object from session 
            System.out.println("Admin Object taken from Session. Scheduled.");
            
            // ========== PROPERTIES ==========
            String idgui, dategui;
            idgui = request.getParameter("docdel");             
            dategui = request.getParameter("daydel"); 
            Formatter format = new Formatter();
            ScheduleBO schedule = new ScheduleBO();
            
            
            // ========== CHECK IF ENTRY ALREADY EXISTS *IT SHOULD* ==========
            schedule.selectDB(idgui, format.formatDateSubmit(dategui));
            if (schedule.getDocId().equals("") 
            && schedule.getDay().equals(""))
            {
                // ----- Go to specific action failed page -----
                response.sendRedirect("admin0shiftexists.html");
            }
            schedule = new ScheduleBO(); // reset for delete
            
            
            // ========== DELETE SHIFT ==========
            schedule.deleteDB(idgui, format.formatDateSubmit(dategui));
            schedule = new ScheduleBO(); // reset for last check
            
            
            // ========== CHECK IF ENTRY STILL EXISTS *IT SHOULD NOT* ==========
            schedule.selectDB(idgui, format.formatDateSubmit(dategui));
            if (!schedule.getDocId().equals("") 
            && !schedule.getDay().equals(""))
            {
                // ----- Go to generic action failed page -----
                response.sendRedirect("actionfailed.html");
            }
            
            
            // ========== RE-LOAD LISTS ==========
            admin.selectDB(admin.getAdminId());
            
            // ========== PUT ADMIN OBJECT BACK IN SESSION ==========
            session.setAttribute("admin", admin); // re-add admin object to session   
            
            // ========== GO BACK TO ADMIN SCHEDULE PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("adminhomeschedule.jsp");
            rd.include(request, response);             
        }
        
        
        
        // ++++++++++ ADD DOCTOR ++++++++++ 
        if (trigger.equals("adddoctor"))
        {
            // ========== GET ADMIN BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            AdminBO admin = (AdminBO)session.getAttribute("admin"); // get admin object from session 
            System.out.println("Admin Object taken from Session. Scheduled.");
            
            // ========== PROPERTIES ==========
            String idgui, pwgui, fngui, lngui, phonegui, emailgui;
            idgui = request.getParameter("newdocid");             
            pwgui = request.getParameter("newdocpw"); 
            fngui = request.getParameter("newdocfn");
            lngui = request.getParameter("newdocln");
            phonegui = request.getParameter("newdocph");
            emailgui = request.getParameter("newdocem");
            DoctorBO doctor = new DoctorBO();
            
            
            // ========== CHECK IF ENTRY ALREADY EXISTS *IT SHOULD NOT* ==========
            doctor.selectDB(idgui);
            if (!doctor.getDocId().equals(""))
            {
                // ----- Go to specific action failed page -----
                response.sendRedirect("admin1doctor1id.html");
            }
            doctor = new DoctorBO(); // reset for insert
            
            
            // ========== INSERT DOCTOR ==========
            doctor.insertDB(idgui, pwgui, fngui, lngui, phonegui, emailgui);
            doctor = new DoctorBO(); // reset for last check
            
            
            // ========== CHECK IF EXISTS AFTER INSERT *IT SHOULD* ==========
            doctor.selectDB(idgui);
            if (doctor.getDocId().equals(""))
            {
                // ----- Go to generic action failed page -----
                response.sendRedirect("actionfailed.html");
            }
            
            
            // ========== RE-LOAD LISTS ==========
            admin.selectDB(admin.getAdminId());
            
            // ========== PUT ADMIN OBJECT BACK IN SESSION ==========
            session.setAttribute("admin", admin); // re-add admin object to session   
            
            // ========== GO BACK TO ADMIN DOCTORS PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("adminhomedoctors.jsp");
            rd.include(request, response);            
        }
        
        
        
        // ++++++++++ DROP DOCTOR ++++++++++ 
        if (trigger.equals("dropdoctor"))
        {
            // ========== GET ADMIN BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            AdminBO admin = (AdminBO)session.getAttribute("admin"); // get admin object from session 
            System.out.println("Admin Object taken from Session. Scheduled.");
            
            // ========== PROPERTIES ==========
            String idgui;
            idgui = request.getParameter("docdel");             
            DoctorBO doctor = new DoctorBO();
            
            
            // ========== CHECK IF ENTRY ALREADY EXISTS *IT SHOULD* ==========
            doctor.selectDB(idgui);
            if (doctor.getDocId().equals(""))
            {
                // ----- Go to specific action failed page -----
                response.sendRedirect("admin0doctorexists.html");
            }
            doctor = new DoctorBO(); // reset for delete
            
            
            // ========== DELETE DOCTOR ==========
            doctor.deleteDB(idgui);
            doctor = new DoctorBO(); // reset for last check
            
            
            // ========== CHECK IF ENTRY STILL EXISTS *IT SHOULD NOT* ==========
            doctor.selectDB(idgui);
            if (!doctor.getDocId().equals(""))
            {
                // ----- Go to generic action failed page -----
                response.sendRedirect("actionfailed.html");
            }
            
            
            // ========== RE-LOAD LISTS ==========
            admin.selectDB(admin.getAdminId());
            
            // ========== PUT ADMIN OBJECT BACK IN SESSION ==========
            session.setAttribute("admin", admin); // re-add admin object to session   
            
            // ========== GO BACK TO ADMIN DOCTORS PAGE ==========
            RequestDispatcher rd = request.getRequestDispatcher("adminhomedoctors.jsp");
            rd.include(request, response);             
        }
        
        
        
        
        
        if (trigger.equals("logout"))
        {
            HttpSession session = request.getSession();
            if(session.getAttribute("admin") != null)
            {
            session.removeAttribute("admin");
            session.invalidate();
            response.sendRedirect("adminlogin.html");                 
            }
            else
            response.sendRedirect("adminlogin.html");      
        }
        
        
        
   
    }
    catch(NullPointerException e)
    {
        /* IF NULL POINTER EXCEPTION OCCURS IN SERVLET - YOU ARE LIKELY NOT
        LOGGED IN AT THE MOMENT - SO YOU WILL BE RE-DIRECTED ACCORDINGLY */
            
        // go to Admin Home Page (session or "trigger" variable related) 
        // ----- this homepage will simply show that user is not logged in
        RequestDispatcher rd = request.getRequestDispatcher("adminhomepage.jsp");
        rd.include(request, response);
    }
    catch(Exception e)
    {
        // go to Unkown Error Home Page 
        RequestDispatcher rd = request.getRequestDispatcher("error.html");
        rd.include(request, response);
    } 
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
