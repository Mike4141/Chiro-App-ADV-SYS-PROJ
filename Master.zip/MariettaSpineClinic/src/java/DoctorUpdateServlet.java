import business.Formatter;
import business.DoctorBO;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/DoctorUpdateServlet"})
public class DoctorUpdateServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();                        
            
        
            // ========== GET DOCTOR BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            DoctorBO doctor = (DoctorBO)session.getAttribute("doctor"); // get doctor object from session 
            System.out.println("Doctor Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========
            String pwGui, phoneGui, emailGui;
            pwGui = request.getParameter("showpw"); // get password from GUI
            phoneGui = request.getParameter("showphone"); // get phone from GUI
            emailGui = request.getParameter("showemail"); // get email from GUI
            Formatter format = new Formatter(); // create formatter object
            String passwIndColor = "gray"; // color of the password hint based on input 
            String phoneIndColor = "gray"; // color of the phone hint based on input 
            String initEditInfo = ""; // Edit mode on start up? default is "" = 'no'
            

            
            // ========== UPDATE PERSONAL INFORMATION IN DATABASE ==========  
            if (format.checkPw(pwGui) == true && format.checkPhone(phoneGui) == true)
            {
                doctor.setDocPw(pwGui);
                doctor.setDocPhone(phoneGui);
                doctor.setDocEmail(emailGui);
                doctor.updateDB();
            }
            else
            {
                // re-start page in edit mode due to incorrect user info
                initEditInfo = "editInfo()"; 
                
                // red indicators for incorrect update input format
                if (format.checkPw(pwGui) == false)
                passwIndColor = "red";
                if (format.checkPhone(phoneGui) == false)
                phoneIndColor = "red";
            }
            
            
            
            // ========= RE-ADD UPDATED DOCTOR BUSINESS OBJECT ==========
            session.setAttribute("doctor", doctor); // add doctor object to session
            System.out.println("Doctor Object re-added to Session. Scheduled.");             
            
            

            // ========== RE-LOAD DOCTOR HOME PAGE ==========
            request.setAttribute("passwHintCol", passwIndColor);
            request.setAttribute("phoneHintCol", phoneIndColor);
            request.setAttribute("initEditInfo", initEditInfo);
            RequestDispatcher rd = request.getRequestDispatcher("doctorhomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - doctorhomepage.jsp");
      
   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
