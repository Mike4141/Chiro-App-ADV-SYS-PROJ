/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import business.AppointmentBO;
import business.Formatter;
import business.PatientBO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author victo
 */
@WebServlet(urlPatterns = {"/PatientUpdateServlet"})
public class PatientUpdateServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            
        try{
        // ++++++++++ GET TRIGGER VALUE ++++++++++
        String trigger = request.getParameter("trigger");
        

        
        
        // ++++++++++ UPDATE PERSONAL INFORMATION ++++++++++        
        if (trigger.equals("updateinfo"))                
        {
            // ========== GET PATIENT BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            PatientBO patient = (PatientBO)session.getAttribute("patient"); // get patient object from session 
            System.out.println("Patient Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========
            String pwGui, phoneGui, emailGui, passwIndColor, phoneIndColor, initEditInfo;
            pwGui = request.getParameter("showpw"); // get password from GUI
            phoneGui = request.getParameter("showphone"); // get phone from GUI
            emailGui = request.getParameter("showemail"); // get email from GUI
            passwIndColor = "gray"; // color of the password hint based on input 
            phoneIndColor = "gray"; // color of the phone hint based on input 
            initEditInfo = ""; // Edit mode on start up? default is "" = 'no'
            Formatter format = new Formatter(); // create formatter object
            
            
            // ========== UPDATE PERSONAL INFORMATION IN DATABASE ==========  
            if (format.checkPw(pwGui) == true && format.checkPhone(phoneGui) == true)
            {
                patient.setPatPw(pwGui);
                patient.setPatPhone(phoneGui);
                patient.setPatEmail(emailGui);
                patient.updateDB();
            }
            else
            {                
                // re-start page in edit mode due to incorrect user info
                initEditInfo = "editInfo()"; 
                
                // red indicators for incorrect update input format
                if (format.checkPw(pwGui) == false)
                passwIndColor = "red";
                if (format.checkPhone(phoneGui) == false)
                phoneIndColor = "red";
            }

            
            // ========== UPDATE PATIENT AND LISTS ==========
            patient.selectDB(patient.getPatId());
            
            
            // ========= RE-ADD UPDATED PATIENT BUSINESS OBJECT ==========
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object re-added to Session. Scheduled.");             
            
            
            // ========== RE-LOAD PATIENT HOME PAGE ==========
            request.setAttribute("passwHintCol", passwIndColor);
            request.setAttribute("phoneHintCol", phoneIndColor);
            request.setAttribute("initEditInfo", initEditInfo);
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");
        }
        
        
        
        
        
        // ++++++++++ SCHEDULE APPOINTMENT ++++++++++
        if (trigger.equals("schedule"))                
        {
            // ========== GET PATIENT BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            PatientBO patient = (PatientBO)session.getAttribute("patient"); // get patient object from session 
            System.out.println("Patient Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========            
            String newApptDay, newApptTimeIn, newApptTimeOut, newApptDocId, initEditInfo;
            newApptDay = request.getParameter("readyday"); // get new appointment day from hidden input
            newApptTimeIn = request.getParameter("readytimein"); // get new appointment time in from hidden input
            newApptTimeOut = request.getParameter("readytimeout"); // get new appointment time out from hidden input
            newApptDocId = request.getParameter("readydocid"); // get new appointment doctor id from hidden input
            initEditInfo = request.getParameter("editing"); // Edit mode on start up? if user is still editing...
            AppointmentBO newAppt = new AppointmentBO(); // new appointment object for scheduling
            Formatter format = new Formatter();
                        
            
            // ========== ADD NEW APPOINTMENT FOR PATIENT ==========           
            newAppt.insertDB(patient.getPatId(), newApptDocId, format.formatDateSubmit(newApptDay), newApptTimeIn, newApptTimeOut);
            
            
            
            // ========== UPDATE PATIENT AND LISTS ==========
            patient.selectDB(patient.getPatId()); 
            
            
            // ========= RE-ADD UPDATED PATIENT BUSINESS OBJECT ==========
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object re-added to Session. Scheduled.");             
            

            // ========== RE-LOAD PATIENT HOME PAGE ==========
            request.setAttribute("passwHintCol", "gray");
            request.setAttribute("phoneHintCol", "gray");
            request.setAttribute("initEditInfo", initEditInfo);
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");
        }
                
        
        
        
        // ++++++++++ CANCEL APPOINTMENT ++++++++++
        if (trigger.equals("cancel"))                
        {
            // ========== GET PATIENT BUSINESS OBJECT FROM SESSION ==========
            HttpSession session; // declare session
            session = request.getSession(); // get session
            PatientBO patient = (PatientBO)session.getAttribute("patient"); // get patient object from session 
            System.out.println("Patient Object taken from Session. Scheduled.");

           
            // ========== PROPERTIES [FROM HOME PAGE] ==========            
            String newApptDay, newApptTimeIn, newApptTimeOut, newApptDocId, initEditInfo;
            newApptDay = request.getParameter("readyday"); // get new appointment day from hidden input
            newApptTimeIn = request.getParameter("readytimein"); // get new appointment time in from hidden input
            newApptDocId = request.getParameter("readydocid"); // get new appointment doctor id from hidden input
            initEditInfo = request.getParameter("editing"); // Edit mode on start up? if user is still editing...
            AppointmentBO endAppt = new AppointmentBO(); // new appointment object for scheduling
            Formatter format = new Formatter();
                        
            
            // ========== DELETE APPOINTMENT FOR PATIENT ==========   
            endAppt.setPatId(patient.getPatId());
            endAppt.setDocId(newApptDocId);
            endAppt.setDay(format.formatDateSubmit(newApptDay));
            endAppt.setTimeIn(newApptTimeIn);
            endAppt.deleteDB();            
            
            
            // ========== UPDATE PATIENT AND LISTS ==========
            patient.selectDB(patient.getPatId());           
            
            
            // ========= RE-ADD UPDATED PATIENT BUSINESS OBJECT ==========
            session.setAttribute("patient", patient); // add patient object to session
            System.out.println("Patient Object re-added to Session. Scheduled.");                         
            

            // ========== RE-LOAD PATIENT HOME PAGE ==========
            request.setAttribute("passwHintCol", "gray");
            request.setAttribute("phoneHintCol", "gray");
            request.setAttribute("initEditInfo", initEditInfo);
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");
        }
        
        
        
        
        // ++++++++++ NO TRIGGER ++++++++++
        if (trigger == null)                
        {
            // ========== RE-LOAD PATIENT HOME PAGE ==========
            request.setAttribute("passwHintCol", "gray");
            request.setAttribute("phoneHintCol", "gray");
            RequestDispatcher rd = request.getRequestDispatcher("patienthomepage.jsp"); // create request dispatcher
            rd.forward(request, response); // forward request dispatcher
            System.out.println("Webpage Loaded - patienthomepage.jsp");        
        }
        
        
        }
        catch(NullPointerException e)
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Login Failed</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+ e +"</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
